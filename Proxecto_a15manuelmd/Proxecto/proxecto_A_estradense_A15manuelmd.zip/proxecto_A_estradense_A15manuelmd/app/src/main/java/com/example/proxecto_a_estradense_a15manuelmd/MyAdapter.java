package com.example.proxecto_a_estradense_a15manuelmd;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.InputStream;
import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    static private ArrayList<Autobus> buses;

    public MyAdapter(Context context, int layout, ArrayList<Autobus> arbuses) {
        this.context = context;
        this.layout = layout;
        buses = new ArrayList<Autobus>();
        for (Autobus b : arbuses) {
            String deBudes = ListaAutobuses.tipo;
            String deArray = b.getTipo();
            if (deBudes.equals(deArray)) {
                buses.add(b);
            }
        }
    }

    @Override
    public int getCount() {
        return this.buses.size();
    }

    @Override
    public Object getItem(int position) {
        return this.buses.get(position);
    }

    @Override
    public long getItemId(int id) {
        return id;
    }

    @Override

    public View getView(int position, View convertView, ViewGroup viewGroup) {

        // Copiamos la vista
        View v = convertView;

        //Inflamos la vista con nuestro propio layout
        LayoutInflater layoutInflater = LayoutInflater.from(this.context);

        v = layoutInflater.inflate(R.layout.listado, null);
        // Valor actual según la posición


        // Referenciamos el elemento a modificar y lo rellenamos
        TextView textView = (TextView) v.findViewById(R.id.titulo);
        TextView tvdesc = (TextView) v.findViewById(R.id.subtitulo);
        textView.setText(buses.get(position).getMarca() + "\n" + buses.get(position).getModelo());
        tvdesc.setText(buses.get(position).getDescripcion());
        //se cargan las imágenes
        String nImg = buses.get(position).getImaxe();
        ImageView imv = v.findViewById(R.id.icono);
        v.findViewById(R.id.lyListado).setBackgroundColor(Color.parseColor(Splash.preferencias.getString("color_primary", "#3FCDE6")));
        try {

            InputStream ims = MainActivity.assets.open(nImg);
            Drawable d = BitmapDrawable.createFromStream(ims, nImg);
            imv.setImageDrawable(d);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                InputStream ims = MainActivity.assets.open("default_bus.png");
                Drawable d = BitmapDrawable.createFromStream(ims, "default_bus.png");
                imv.setImageDrawable(d);
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return v;
    }

}