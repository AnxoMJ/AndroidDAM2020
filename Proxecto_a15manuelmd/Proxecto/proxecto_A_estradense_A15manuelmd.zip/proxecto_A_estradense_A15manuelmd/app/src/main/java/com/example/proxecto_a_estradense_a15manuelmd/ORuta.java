package com.example.proxecto_a_estradense_a15manuelmd;

public class ORuta {
    int id_ruta;
    String primeira_parada;
    String segunda_parada;

    @Override
    public String toString() {
        return primeira_parada + " - " + segunda_parada;
    }
}
