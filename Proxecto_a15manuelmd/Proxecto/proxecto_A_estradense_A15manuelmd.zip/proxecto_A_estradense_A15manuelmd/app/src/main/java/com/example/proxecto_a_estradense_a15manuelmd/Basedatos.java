package com.example.proxecto_a_estradense_a15manuelmd;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class Basedatos extends SQLiteOpenHelper {

    public SQLiteDatabase sqlLiteDB;

    public final static String NOME_BD = "bdHorarios.db";
    public final static int VERSION_BD = 1;

    private final static String CREAR_TABOA_RUTA = "CREATE TABLE RUTA ( " +
            "id_ruta  INTEGER PRIMARY KEY AUTOINCREMENT)";
    private final static String CREAR_TABOA_PARADA = "CREATE TABLE PARADA ( " +
            "id_parada  INTEGER PRIMARY KEY AUTOINCREMENT," +
            "nome VARCHAR(20))";
    private final static String CREAR_TABOA_PARADAS = "CREATE TABLE PARADAS ( " +
            "id_parada  INTEGER," +
            "id_ruta REFERENCES RUTA (id_ruta)," +
            "orde INTEGER," +
            "PRIMARY KEY (id_parada, id_ruta ))";
    private final static String CREAR_TABOA_HORARIO = "CREATE TABLE HORARIO ( " +
            "id_horario  INTEGER PRIMARY KEY AUTOINCREMENT," +
            "id_ruta REFERENCES RUTA (id_ruta) ," +
            "tipo_dia INTEGER)";
    private final static String CREAR_TABOA_HORA = "CREATE TABLE HORA ( " +
            "id_horario  INTEGER," +
            "hora VARCHAR(6),"+
            "PRIMARY KEY (id_horario, hora))";


    public Basedatos(Context context) {
        super(context, NOME_BD, null, VERSION_BD);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREAR_TABOA_RUTA);
        db.execSQL(CREAR_TABOA_PARADA);
        db.execSQL(CREAR_TABOA_PARADAS);
        db.execSQL(CREAR_TABOA_HORARIO);
        db.execSQL(CREAR_TABOA_HORA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

   public void engadirRuta(ORuta ruta){
       ContentValues datosexemplo = new ContentValues();
       datosexemplo.put("id_ruta", ruta.id_ruta);
       long idFila1 = sqlLiteDB.insert("RUTA", null, datosexemplo);
   }
    public void engadirParada(OParada parada){
        ContentValues datosexemplo = new ContentValues();
        datosexemplo.put("id_parada", parada.id_parada);
        datosexemplo.put("nome", parada.nome);
        long idFila1 = sqlLiteDB.insert("PARADA", null, datosexemplo);
    }
    public void engadirParadas(OParadas paradas){
        ContentValues datosexemplo = new ContentValues();
        datosexemplo.put("id_parada", paradas.id_parada);
        datosexemplo.put("id_ruta", paradas.id_ruta);
        datosexemplo.put("orde", paradas.orde);
        long idFila1 = sqlLiteDB.insert("PARADAS", null, datosexemplo);
    }
    public void engadirHorario(OHorario horario){
        ContentValues datosexemplo = new ContentValues();
        datosexemplo.put("id_horario", horario.id_horario);
        datosexemplo.put("id_ruta", horario.id_ruta);
        datosexemplo.put("tipo_dia", horario.tipo_dia);
        long idFila1 = sqlLiteDB.insert("HORARIO", null, datosexemplo);
    }
    public void engadirHora(OHora hora){
        ContentValues datosexemplo = new ContentValues();
        datosexemplo.put("id_horario", hora.id_horario);
        datosexemplo.put("hora", hora.hora);
        long idFila1 = sqlLiteDB.insert("HORA", null, datosexemplo);
    }

    public ArrayList<ORuta> listaRuta(){
        Cursor cursor = sqlLiteDB.rawQuery("select id_ruta from RUTA", null);
        ArrayList<ORuta> arRuta=new ArrayList<>();
        if (cursor.moveToFirst()) {                // Se non ten datos xa non entra
            while (!cursor.isAfterLast()) {
                ORuta nRuta=new ORuta();
                nRuta.id_ruta=cursor.getInt(0);
                nRuta.primeira_parada=sacarParada(paradaInicio(nRuta.id_ruta));
                nRuta.segunda_parada=sacarParada(paradaDestino(nRuta.id_ruta));
                arRuta.add(nRuta);
                cursor.moveToNext();
            }
        }
        return arRuta;
    }
    public int paradaInicio(int idRuta){
        Cursor cursor = sqlLiteDB.rawQuery("select id_parada from PARADAS where  orde=0 and id_ruta="+idRuta+" order by orde", null);
        if (cursor.moveToFirst()) {                // Se non ten datos xa non entra
            while (!cursor.isAfterLast()) {
               return cursor.getInt(0);
               // cursor.moveToNext();
            }
        }
        return -1;
    }
    public int paradaDestino(int idRuta){
       // Cursor cursor = sqlLiteDB.rawQuery("select id_parada from PARADAS where orde=(select max(orde) from PARADAS where id_ruta="+idRuta+")", null);
         Cursor cursor = sqlLiteDB.rawQuery("select id_parada from PARADAS where id_ruta="+idRuta+" order by orde", null);
            int pard=0;
        if (cursor.moveToFirst()) {                // Se non ten datos xa non entra
            while (!cursor.isAfterLast()) {
                pard= cursor.getInt(0);
                cursor.moveToNext();
            }
        }
        return pard;
    }
    public String sacarParada(int idParada){
        Cursor cursor = sqlLiteDB.rawQuery("select * from PARADA where id_parada="+idParada, null);
        if (cursor.moveToFirst()) {                // Se non ten datos xa non entra
            while (!cursor.isAfterLast()) {
               return cursor.getString(1);
               // cursor.moveToNext();
            }
        }
        return "";
    }
    public ArrayList<String> sacarParadas(int idRuta){
        Cursor cursor = sqlLiteDB.rawQuery("select id_parada from PARADAS where id_ruta="+idRuta+" order by orde", null);
        ArrayList<String>arPards=new ArrayList<>();
        if (cursor.moveToFirst()) {                // Se non ten datos xa non entra
            while (!cursor.isAfterLast()) {
              arPards.add(sacarParada(cursor.getInt(0)));
                 cursor.moveToNext();
            }
        }
        return arPards;
    }
    public ArrayList<String> sacarHoras(int idhorario){
        Cursor cursor = sqlLiteDB.rawQuery("select hora from HORA where id_horario="+idhorario, null);
        ArrayList<String>arPards=new ArrayList<>();
        if (cursor.moveToFirst()) {                // Se non ten datos xa non entra
            while (!cursor.isAfterLast()) {
                arPards.add(cursor.getString(0));
                cursor.moveToNext();
            }
        }
        return arPards;
    }
    public int sacaridHorario(int idRuta, int tipo){
        Cursor cursor = sqlLiteDB.rawQuery("select id_horario from HORARIO where id_ruta="+idRuta+" and tipo_dia="+tipo, null);

        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
               return cursor.getInt(0);
                //cursor.moveToNext();
            }
        }
        return -1;
    }

}
