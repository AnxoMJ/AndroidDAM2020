package com.example.proxecto_a_estradense_a15manuelmd;

public class Autobus {
    private String tipo;
    private String marca;
    private String modelo;
    private String imaxe;
    private String descripcion;

    public Autobus(String tipo, String marca, String modelo, String imaxe,String descripcion) {
        this.tipo = tipo;
        this.marca = marca;
        this.modelo = modelo;
        this.imaxe = imaxe;
        this.descripcion=descripcion;
    }

    public Autobus() {
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getImaxe() {
        return imaxe;
    }

    public void setImaxe(String imaxe) {
        this.imaxe = imaxe;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
