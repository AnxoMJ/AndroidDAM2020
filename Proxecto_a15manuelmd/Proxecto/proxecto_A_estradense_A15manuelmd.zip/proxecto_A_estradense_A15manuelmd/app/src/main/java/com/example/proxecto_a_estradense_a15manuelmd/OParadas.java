package com.example.proxecto_a_estradense_a15manuelmd;

public class OParadas {
    int id_ruta;
    int id_parada;
    int orde;
}
