package com.example.proxecto_a_estradense_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;

import java.util.prefs.Preferences;

public class Splash extends AppCompatActivity {
    static MediaPlayer mediaPlayer;
    static SharedPreferences preferencias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        preferencias = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        LinearLayout ly = findViewById(R.id.lySplash);
        ly.setBackgroundColor(Color.parseColor(Splash.preferencias.getString("color_primary", "#3FCDE6")));
        pararAMain.start();

    }

    Thread pararAMain = new Thread(new Runnable() {
        @Override
        public void run() {
            SharedPreferences preferencias = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            if (preferencias.getBoolean("start_song", true)) {
                mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.himno);
                mediaPlayer.start();
            }
            try {
                Thread.sleep(Integer.valueOf(Splash.preferencias.getString("vel_logo", "1500")));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);

            finish();
        }
    });

}
