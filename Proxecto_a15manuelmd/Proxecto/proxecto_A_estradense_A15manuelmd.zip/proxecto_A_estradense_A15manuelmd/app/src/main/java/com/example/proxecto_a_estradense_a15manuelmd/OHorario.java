package com.example.proxecto_a_estradense_a15manuelmd;

public class OHorario {
    int id_ruta;
    int id_horario;
    int tipo_dia;
}
