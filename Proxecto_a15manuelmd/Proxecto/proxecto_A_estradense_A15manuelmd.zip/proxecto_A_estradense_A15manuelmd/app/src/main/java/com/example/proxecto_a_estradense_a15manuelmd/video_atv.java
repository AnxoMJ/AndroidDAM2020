package com.example.proxecto_a_estradense_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class video_atv extends AppCompatActivity {
    VideoView vid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_video_atv);
        vid = (VideoView) findViewById(R.id.videoVista);
        MediaController m = new MediaController(this);
        Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.cortito);
        vid.setVideoURI(uri);
        vid.start();
        estaReproducindose.start();
    }

    Thread estaReproducindose = new Thread(new Runnable() {
        @Override
        public void run() {
            while (!vid.isPlaying()) {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {}
            }
            while (vid.isPlaying()) {
               // Log.i("posicion", String.valueOf(vid.getCurrentPosition()));
               // Log.i("duracion", String.valueOf(vid.getDuration()));
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {}
            }
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {}
            showToast("Goodbye");
            MainActivity.actual.finish();
            finish();
        }
    });

    public void showToast(final String toast) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(video_atv.this.getApplicationContext(), toast, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
