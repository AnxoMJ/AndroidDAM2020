package com.example.proxecto_a_estradense_a15manuelmd;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.Xml;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    static AssetManager assets;
    static MainActivity actual;
    private LinearLayout ly;
    static Basedatos base;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        assets = getAssets();
        parse();
        ly = findViewById(R.id.mainLy);
        ly.setBackgroundColor(Color.parseColor(Splash.preferencias.getString("color_primary", "#3FCDE6")));
        base = new Basedatos(this);
        if (!new File(getDatabasePath("bdHorarios.db").getAbsolutePath()).exists()) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        transformarHtml(getAssets().open("estradense.html"));
                        //transformarHtml(new FileInputStream(getFilesDir()+"/horDesc.html"));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
        base.sqlLiteDB = base.getWritableDatabase();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        parse();
        ly.setBackgroundColor(Color.parseColor(Splash.preferencias.getString("color_primary", "#3FCDE6")));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.itemPreferencias) {
            Intent intent = new Intent(getApplicationContext(), preferencias.class);
            startActivityForResult(intent, 1);
        } else {
            cargarfichero();
        }
        return true;
    }

    public void cargarfichero() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                   descargarArquivo(new URL("http://www.radioestrada.com/index.php/axenda-cultural/663"));
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            InputStream in1= null;
                            try {
                                //in1 = new FileInputStream(getFilesDir()+"/horDesc.html");
                                //transformarHtml(in1);
                               transformarHtml(getAssets().open("estradense.html"));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            Toast.makeText(getApplicationContext(), R.string.updDats,Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void descargarArquivo(URL url) {
        HttpURLConnection conn = null;
        String nomeArquivo = Uri.parse("horDesc.html").getLastPathSegment();
        File rutaArquivo = new File(getFilesDir() + File.separator + nomeArquivo);

        try {

            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);    /* milliseconds */
            conn.setConnectTimeout(15000);  /* milliseconds */
            conn.setRequestMethod("POST");
            conn.setDoInput(true);            /* Indicamos que a conexión vai recibir datos */

            conn.connect();

            int response = conn.getResponseCode();
            if (response != HttpURLConnection.HTTP_OK) {
                return;
            }
            OutputStream os = new FileOutputStream(rutaArquivo);
            InputStream in = conn.getInputStream();
            byte data[] = new byte[1024];    // Buffer a utilizar
            int count;
            while ((count = in.read(data)) != -1) {
                os.write(data, 0, count);
            }
            os.flush();
            os.close();
            in.close();
            conn.disconnect();
            Log.i("COMUNICACION", "ACABO");
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("COMUNICACION", e.getMessage());
        }

    }

    public void onClickBoton1(View v) {
        Intent intent = new Intent(this, ListaRutas.class);
        startActivity(intent);
    }

    public void onClickBotonBuses(View v) {
        Intent intent = new Intent(this, ListaAutobuses.class);
        startActivity(intent);
        actual = this;
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            Splash.mediaPlayer.stop();
        } catch (Exception e) {
            Log.e("PausaCancion", "Error pechando a canción");
        }
    }

    ///parte dos recursos xml dos autobuses
    public void parse() {
        try {
            String idioma = getResources().getConfiguration().locale.getDisplayLanguage().toString();
            InputStream is;
            if (idioma.equals("English"))
                is = getAssets().open("Autobuses_en.xml");
            else if (Splash.preferencias.getBoolean("joke_mode", false))
                is = getAssets().open("Autobuses_broma.xml");
            else
                is = getAssets().open("Autobuses.xml");
            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(is, "UTF-8");
            TextView tv = findViewById(R.id.tv);
            int evento = parser.nextTag();
            ListaAutobuses.arBuses.clear();
            Autobus bus = null;
            while (evento != XmlPullParser.END_DOCUMENT) {
                if (evento == XmlPullParser.START_TAG) {
                    if (parser.getName().equals("autobus")) {    // Un novo autobus

                        bus = new Autobus();
                        evento = parser.nextTag();    // Pasamos a <tipo>
                        //tv.append(parser.nextText());
                        bus.setTipo(parser.nextText());
                        evento = parser.nextTag();    // Pasamos a <marca>
                        //tv.append(parser.nextText());
                        bus.setMarca(parser.nextText());
                        evento = parser.nextTag();    // Pasamos a <modelo>
                        //tv.append(parser.nextText());
                        bus.setModelo(parser.nextText());
                        evento = parser.nextTag();    // Pasamos a <imaxe>
                        //tv.append(parser.nextText());
                        bus.setImaxe(parser.nextText());
                        evento = parser.nextTag();    // Pasamos a <descricion>
                        //tv.append(parser.nextText());
                        bus.setDescripcion(parser.nextText());

                    }
                }
                if (evento == XmlPullParser.END_TAG) {
                    if (parser.getName().equals("autobus")) {    // Un novo autobus
                        ListaAutobuses.arBuses.add(bus);
                    }
                }
                evento = parser.next();
            }
            is.close();
        } catch (Exception e) {
        }
    }

    //parse do html da paxina web
    public void transformarHtml(InputStream is) {
        ArrayList<OParada> arParada = new ArrayList<OParada>();
        ArrayList<OParadas> arParadas = new ArrayList<OParadas>();
        ArrayList<ORuta> arRuta = new ArrayList<ORuta>();
        ArrayList<OHorario> arHorario = new ArrayList<OHorario>();
        ArrayList<OHora> arHora = new ArrayList<OHora>();
        try {
            TextView tv = findViewById(R.id.tv);
            tv.setText("");
            // InputStream is = getAssets().open("estradense.html");
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String verso;
            String valorFinal = "";
            ArrayList<String> arDatos = new ArrayList<String>();
            int contNext = 0;
            while ((verso = br.readLine()) != null) {
                if (verso.matches("^<p>.*")) {
                    verso = verso.replace("<p>", "");
                    verso = verso.replace("</p>", "");
                    if (verso.equals("&nbsp;")) {
                        if (!valorFinal.equals("")) {
                            valorFinal = valorFinal.replace("&nbsp;", "");
                            valorFinal = valorFinal.replaceFirst("\n", "");
                            arDatos.add(valorFinal);
                            valorFinal = "";
                        }
                    }
                    if (verso.matches("^<strong>.*")) {
                        verso = verso.replace("<strong>", "");
                        verso = verso.replace("</strong>", "");
                        if (verso != "") {
                            valorFinal += verso + "\n";
                            //arDatos.add(valorFinal);
                            //valorFinal="";
                        }
                    } else {
                        verso = verso.replaceAll("</div>", "");
                        if (verso != "")
                            valorFinal += verso + "\n";
                    }
                }
            }
            /////////////////////////////////////////parte na que se sacan datos
            int cont = 0;
            //consiguo os datos da primeira parada
            // String temporalius = arDatos.get(1);
            boolean ten = true;
            for (String temporalius : arDatos) {
                cont = 0;
                String tempor[] = temporalius.split("\n");
                //saco os horarios e a parada
                for (String s : tempor) {
                    String nomeHor[] = s.split(":");
                    if (!ten)
                        break;
                    if (cont == 0) {
                        //engado a ruta
                        ORuta nRuta = new ORuta();
                        nRuta.id_ruta = arRuta.size() + 1;
                        arRuta.add(nRuta);
                        //saco o nome de cada parada

                       // tv.append(nomeHor[0] + "\n");
                        int contParada = 0;
                        for (String parada : (nomeHor[0]).split("-")) {
                            //tv.append(parada + "\n");
                            OParada nParada = new OParada();
                            nParada.id_parada = arParada.size();
                            nParada.nome = parada;
                            boolean tiene = false;
                            for (OParada opr : arParada) {
                                if (opr.nome.equals(parada)) {
                                    OParadas pards = new OParadas();
                                    pards.orde = contParada;
                                    pards.id_ruta = arRuta.size();
                                    pards.id_parada = opr.id_parada;
                                    arParadas.add(pards);
                                    tiene = true;
                                    break;
                                }
                            }
                            if (!tiene) {
                                arParada.add(nParada);
                                OParadas pards = new OParadas();
                                pards.orde = contParada;
                                pards.id_ruta = arRuta.size();
                                pards.id_parada = nParada.id_parada;
                                arParadas.add(pards);
                            }
                            contParada++;
                        }
                    } else {
                        if (!ten)
                            continue;
                        //Saco nome horario
                        // tv.append(nomeHor[0] + "\n");
                        OHorario nOHorario = new OHorario();
                        nOHorario.id_horario = arHorario.size() + 1;
                        nOHorario.id_ruta = arRuta.size();
                        //nOHorario.tipo_dia = nomeHor[0];
                        switch (nomeHor[0]) {
                            case "De Luns a Venres Laborables":
                                nOHorario.tipo_dia = 1;
                                break;
                            case "Sábados":
                                nOHorario.tipo_dia = 2;
                                break;
                            case "Domingos e Festivos":
                                nOHorario.tipo_dia = 3;
                                break;
                            default:
                                ten = false;
                                break;
                        }
                        //non engade unha ruta se non ten estos horarios....
                        if (!ten) {
                            continue;
                        }

                        arHorario.add(nOHorario);
                        // tv.append(nomeHor[0] + "\n");

                        String testo[] = s.split(nomeHor[0] + ":");
                        //saco horario
                        // tv.append(testo[1] + "\n");
                        for (String sHora : testo[1].split("-")) {
                            //tv.append(sHora.replace(" ","")+ "\n");
                            OHora nOHora = new OHora();
                            nOHora.id_horario = arHorario.size();
                            nOHora.hora = sHora.replace(" ", "");
                            arHora.add(nOHora);
                        }
                    }
                    cont++;
                }
            }
            cargarDatosBd(arRuta, arParadas, arParada, arHorario, arHora);
            br.close();
            is.close();
        } catch (Exception ex) {
            Log.e("FICHEIROS", "Error ao ler ficheiro dende recurso raw");
            ex.printStackTrace();
        }
    }

    public void cargarDatosBd(ArrayList<ORuta> arRuta, ArrayList<OParadas> arParadas, ArrayList<OParada> arParada, ArrayList<OHorario> arHorario, ArrayList<OHora> arHora) {
        File fBase = new File(getDatabasePath("bdHorarios.db").getAbsolutePath());
        if (fBase.exists())
            fBase.delete();

        Basedatos base = new Basedatos(this);
        base.sqlLiteDB = base.getWritableDatabase();
        for (ORuta r : arRuta) {
            base.engadirRuta(r);
        }
        for (OParada r : arParada) {
            base.engadirParada(r);
        }
        for (OParadas r : arParadas) {
            base.engadirParadas(r);
        }
        for (OHorario r : arHorario) {
            base.engadirHorario(r);
        }
        for (OHora r : arHora) {
            base.engadirHora(r);
        }
    }
}
