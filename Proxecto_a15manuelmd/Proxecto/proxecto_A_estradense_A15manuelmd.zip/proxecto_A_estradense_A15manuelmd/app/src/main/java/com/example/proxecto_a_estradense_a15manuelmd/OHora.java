package com.example.proxecto_a_estradense_a15manuelmd;

public class OHora {
    int id_horario;
    String hora;
}
