package com.example.proxecto_a_estradense_a15manuelmd;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;

public class ListaAutobuses extends AppCompatActivity {
    static ArrayList<Autobus> arBuses = new ArrayList<Autobus>();
    static String tipo = "";
    static ListView lvBuses;
    static MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_de_autobuses);
        lvBuses = findViewById(R.id.listaBuses);
        final Spinner spinner = findViewById(R.id.spTiposBuses);
        findViewById(R.id.listaBuses).setBackgroundColor(Color.parseColor(Splash.preferencias.getString("color_primary", "#3FCDE6")));
        spinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.string_array_tipos_buses)));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tipo = spinner.getSelectedItem().toString();
                myAdapter = new MyAdapter(getApplicationContext(), R.layout.listado, arBuses);
                lvBuses.setAdapter(myAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        lvBuses.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int pos, long id) {
                String idioma = getResources().getConfiguration().locale.getDisplayLanguage();
                if (!idioma.equals("English") && Splash.preferencias.getBoolean("joke_mode", false) && pos == 2) {
                    Intent intent = new Intent(getApplicationContext(), video_atv.class);
                    startActivity(intent);
                    finish();
                    return true;
                }
                ImageView imv = arg1.findViewById(R.id.icono);
                ZommImaxe.d = imv.getDrawable();
                Intent intent2 = new Intent(getApplicationContext(), ZommImaxe.class);
                startActivity(intent2);
                return true;
            }
        });
        lvBuses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView tv = view.findViewById(R.id.subtitulo);
                Toast.makeText(getApplicationContext(), tv.getText(), Toast.LENGTH_LONG).show();
            }
        });
        avisoBroma();
    }

    public void avisoBroma() {
        String idioma = getResources().getConfiguration().locale.getDisplayLanguage();

        if (idioma.equals("English") || !Splash.preferencias.getBoolean("joke_mode", false))
            return;
        AlertDialog.Builder venta = new AlertDialog.Builder(this);
        venta.setIcon(android.R.drawable.ic_dialog_info);
        venta.setTitle("Aviso");
        venta.setMessage(getString(R.string.avisoBroma));
        venta.setCancelable(false);
        venta.setPositiveButton("Si", null);
        venta.setNegativeButton("Non", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int boton) {
                Toast.makeText(getApplicationContext(), "Pechando", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        venta.create().show();
    }
}
