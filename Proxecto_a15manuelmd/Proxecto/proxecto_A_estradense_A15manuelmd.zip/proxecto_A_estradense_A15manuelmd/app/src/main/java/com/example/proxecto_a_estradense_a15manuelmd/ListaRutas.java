package com.example.proxecto_a_estradense_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;

public class ListaRutas extends AppCompatActivity {

    Spinner spRutas;
    TextView tvParadas;
    TextView tvHoras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rutas);
        findViewById(R.id.lyRuta).setBackgroundColor(Color.parseColor(Splash.preferencias.getString("color_primary", "#3FCDE6")));
        tvParadas = findViewById(R.id.paradRutas);
        tvHoras = findViewById(R.id.horasRutas);
        spRutas = findViewById(R.id.spRuta);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                cargarArRutas();
            }
        });
        spRutas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        cargarParadas();
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(new Date());
                        int dia=(calendar.get(Calendar.DAY_OF_WEEK));
                        Log.i("dia",String.valueOf(dia));
                            if (dia <=6 && dia >1)
                            cargarHorarios(1);
                            else if (dia==7)
                                cargarHorarios(2);
                            else
                                cargarHorarios(3);
                    }
                });
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_l_buses, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                cargarHorarios(3);
            }
        });
        return true;
    }

    public void cargarArRutas() {
        ArrayList<ORuta> arRutas = new ArrayList<ORuta>();
        for (ORuta r : MainActivity.base.listaRuta()) {
            arRutas.add(r);
        }
        ArrayAdapter<ORuta> adaptador = new ArrayAdapter<ORuta>(this, android.R.layout.simple_spinner_item, arRutas);
        spRutas.setAdapter(adaptador);
    }

    public void cargarParadas() {
        tvParadas.setText("");
        ORuta ruta = (ORuta) spRutas.getSelectedItem();
        tvParadas.append(getString(R.string.lparads) + "\n\n");
        tvParadas.append("| ");
        for (String s : MainActivity.base.sacarParadas(ruta.id_ruta)) {
            tvParadas.append(s);
            tvParadas.append(" | ");
        }
    }

    public void cargarHorarios(int tipo) {
        ORuta ruta = (ORuta) spRutas.getSelectedItem();
        tvHoras.setText("");
        int cHor = MainActivity.base.sacaridHorario(ruta.id_ruta, tipo);
        //Toast.makeText(this,cHor,Toast.LENGTH_LONG);
        if (cHor == -1) {
            Toast.makeText(this, R.string.notService, Toast.LENGTH_LONG).show();
            tvHoras.append(getResources().getString(R.string.notService));
            return;
        }
        ArrayList<String> arHoras = MainActivity.base.sacarHoras(cHor);
        ArrayList<Date> arHorasDate = new ArrayList<>();
        tvHoras.append("\n\n\n");
        switch (tipo) {
            case 1:
                tvHoras.append(getString(R.string.laV));
                break;
            case 2:
                tvHoras.append(getString(R.string.sab));
                break;
            case 3:
                tvHoras.append(getString(R.string.doms));
                break;

        }
        tvHoras.append("\n\n");
        for (String s : arHoras) {
            try {
                arHorasDate.add(new SimpleDateFormat("HH:mm").parse(s));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        Collections.sort(arHorasDate);

         tvHoras.append("| ");
        for (Date d : arHorasDate) {
            tvHoras.append(new SimpleDateFormat("HH:mm").format(d) + " | ");

        }
    }
}
