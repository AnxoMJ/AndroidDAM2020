package com.example.proxecto_a_estradense_a15manuelmd;

public class OParada {
    int id_parada;
    String nome;
}
