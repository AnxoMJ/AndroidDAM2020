package com.example.av1_1pa15manuelmd;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.DialogFragment;

public class DialogFragmFroitas extends DialogFragment {
    static TextView tvmain=null;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder venta = new AlertDialog.Builder(getActivity());
        venta = new AlertDialog.Builder(getContext());
        venta.setIcon(android.R.drawable.ic_dialog_info);
        venta.setTitle("Selecciona modos de transporte");
        Resources res = getResources();

        final String[] matriz = MainActivity.froitas;
        final boolean[] selecTemp=new boolean[3];
        int i=0;
        for (boolean b : MainActivity.seleccionadas){
            selecTemp[i]=b;
            i++;
        }
        venta.setMultiChoiceItems(matriz, selecTemp, new DialogInterface.OnMultiChoiceClickListener() {
            public void onClick(DialogInterface dialog, int opcion, boolean isChecked) {
                if (isChecked)
                    Toast.makeText(getContext(), "Seleccionaches " + matriz[opcion], Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getContext(), "Deseleccionaches " + matriz[opcion], Toast.LENGTH_SHORT).show();
            }
        });
        venta.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int boton) {
                int i=0;
                tvmain.setText("");
                for (boolean b : selecTemp){
                    if (b)
                        tvmain.append(MainActivity.froitas[i]+"\n");
                    i++;
                }
                Toast.makeText(getContext(), "Premches 'Aceptar' ", Toast.LENGTH_SHORT).show();
                MainActivity.seleccionadas=selecTemp;
            }
        });
        venta.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int boton) {
                Toast.makeText(getContext(), "Premeches 'Cancelar'", Toast.LENGTH_SHORT).show();
            }
        });
        return venta.create();
    }
    public void setTvmain(TextView tv){
        tvmain=tv;
    }
}
