package com.example.av1_1pa15manuelmd;

import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends FragmentActivity {
    static  String[] froitas = new String[] { "Pera", "Mazá", "Plátano" };
    static  boolean[] seleccionadas = new boolean[] { false, true, false };
    private static final int CODIGO_IDENTIFICADOR =1 ;
    static String carpeta="";
    TextView tv;
    File dirFicheiro;
    File rutaCompleta;
    public static String nomeFicheiro = "Cities.txt";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv=findViewById(R.id.tvDatos);
    }
    public void cBtLview(View v){
        Intent intent = new Intent(this, ActivityListView.class);
        startActivity(intent);
    }

    public void cBtDfF(View v){
        FragmentManager fm = getSupportFragmentManager();
        DialogFragmFroitas dialogo=new DialogFragmFroitas();
        dialogo.setTvmain(tv);
        dialogo.show(fm,"dialogo");
    }
    public void cBtnWrAdd(View v){
        EditText etFolder = (EditText) findViewById(R.id.edtFolder);
        EditText etCity = (EditText) findViewById(R.id.edtCity);
        CheckBox cbSobrescribir = (CheckBox) findViewById(R.id.chbOvw);
        boolean sobrescribir = false;
        sobrescribir = !(cbSobrescribir.isChecked());
        tv.setText("");
        dirFicheiro = getFilesDir();
        rutaCompleta = new File(dirFicheiro.getAbsolutePath(), nomeFicheiro);
        try {
            File fcarpeta=new File(dirFicheiro.toString());
                if (!etFolder.getText().toString().equals("")){
                    String etf=etFolder.getText().toString();
                    carpeta="/"+etf+"/";
                    fcarpeta=new File(dirFicheiro.toString()+carpeta);
                    fcarpeta.mkdir();
                }
                OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(fcarpeta+"/"+nomeFicheiro, sobrescribir));
               if(!etCity.getText().toString().equals(""))
                osw.write(etCity.getText().toString() + "\n");
                osw.close();
           // Toast.makeText(getApplicationContext(),fcarpeta+"/"+nomeFicheiro,Toast.LENGTH_SHORT).show();
            Log.e("Interna", "gardouse en : "+fcarpeta+"/"+nomeFicheiro);
            etCity.setText("");

            } catch (Exception ex) {
                Toast.makeText(getApplicationContext(),"error",Toast.LENGTH_SHORT).show();
                Log.e("Interna", "Error escribindo no ficheiro");
            }
}

    public void cBtnRead(View v){
        dirFicheiro = getFilesDir();
        rutaCompleta = new File(dirFicheiro.getAbsolutePath(), nomeFicheiro);
        String linha = "";
        TextView tv = (TextView) findViewById(R.id.tvDatos);
        tv.setText(linha);
        EditText etFolder = (EditText) findViewById(R.id.edtFolder);
        if (!etFolder.getText().toString().equals("")){
            String etf=etFolder.getText().toString();
            carpeta="/"+etf+"/";
        }
            try {
                File fcarpeta=new File(dirFicheiro.toString()+carpeta);
                BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fcarpeta+"/"+nomeFicheiro)));
                while ((linha = br.readLine()) != null)

                    tv.append(linha + "\n");
                br.close();
            } catch (Exception ex) {
                Toast.makeText(this, "Problemas lendo o ficheiro", Toast.LENGTH_SHORT).show();
                Log.e("Interna", "Erro lendo o ficheiro. ");
            }
    }

    public void cBtnChamar(View v){
        if (Build.VERSION.SDK_INT>=23){

            int permiso = checkSelfPermission(Manifest.permission.CALL_PHONE);

            if (permiso ==PackageManager.PERMISSION_GRANTED){
                chamarTelefono();
            }
            else{
                MainActivity.this.requestPermissions( new String[]{Manifest.permission.CALL_PHONE},CODIGO_IDENTIFICADOR);
            }
        }else
            chamarTelefono();
    }
    public void chamarTelefono(){
        EditText edtTLF=findViewById(R.id.edtTLF);
        if(!edtTLF.getText().toString().equals("")){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:"+edtTLF.getText().toString()));
        startActivity(callIntent);
        }else
            Toast.makeText(getApplicationContext(),R.string.avisoTlVacio,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case CODIGO_IDENTIFICADOR: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    chamarTelefono();
                } else {
                    Toast.makeText(this,R.string.permisosTlf,Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }
}
