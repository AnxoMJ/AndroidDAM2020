package com.example.t1f_a15manuelmd;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class T1F_a15manuelmd extends AppCompatActivity {
    private final int CODIGO_IDENTIFICADOR=1;
     public static String nFileColors = "PrefColors.conf";
     static String name="";
     static ArrayList<String> arLovFinal=new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setColorName();
    }

//encargase de recargar o  listview se se estaba amosando
    @Override
    protected void onResume() {
        if(!arLovFinal.isEmpty()){
            EditText edtName =findViewById(R.id.edtName);
            if (!edtName.getText().toString().equals("")) {
                cargarLovers();
            }
        }
        super.onResume();
    }

    public void onbtnLovers(View v){
        EditText edtName =findViewById(R.id.edtName);
        if (edtName.getText().toString().equals("")){
            Toast.makeText(this,R.string.name_empty,Toast.LENGTH_LONG).show();
            return;
        }
        name=edtName.getText().toString();
        Intent intent = new Intent(this, Lovers.class);
        startActivity(intent);
    }

    //Parte cargar Lovers
    public void onbtnShowLovers(View v){
        EditText edtName =findViewById(R.id.edtName);
        if (edtName.getText().toString().equals("")){
            Toast.makeText(this,R.string.name_empty,Toast.LENGTH_LONG).show();
            return;
        }
        name=edtName.getText().toString();
        AlertDialog.Builder venta = new AlertDialog.Builder(this);
        venta.setIcon(android.R.drawable.ic_dialog_info);
        venta.setTitle(R.string.show_lovers);
        venta.setCancelable(false);
        venta.setPositiveButton(R.string.opt_display, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int boton) {
                cargarLovers();
            }

        });
        venta.setNegativeButton(R.string.opt_no_display, null);
        arLovFinal=new ArrayList<String>();
        ListView lvLovers =findViewById(R.id.lvSLovers);
        lvLovers.setAdapter(null);
        venta.create();
        venta.show();
    }

public void cargarLovers(){
    try {
    ListView lvLovers =findViewById(R.id.lvSLovers);
    lvLovers.setAdapter(null);
    ArrayList<String> volcadoFLovers= new ArrayList<String>();
    File rutaCompleta=new File(getFilesDir()+"/"+T1F_a15manuelmd.name);
    rutaCompleta.mkdir();
    String linha="";

    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(rutaCompleta+"/"+Lovers.nomeFicheiro)));
    while ((linha = br.readLine()) != null)
        volcadoFLovers.add(linha);
    br.close();

    int acumulLoversT=0;
        arLovFinal=new ArrayList<String>();
        arLovFinal.add("Total_Lovers       Month.");
            for (String s : Lovers.arMeses){
                acumulLoversT=0;
                for (String loversF : volcadoFLovers){
                    String lovers[]=loversF.split(" ");
                    if (s.equals(lovers[0]))
                        acumulLoversT+=Integer.valueOf(lovers[1]);
                }
                arLovFinal.add(acumulLoversT+"             "+s);
            }

        lvLovers.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,arLovFinal));

    } catch (Exception ex) {

        Toast.makeText(this, getString( R.string.err_file)+" lovers.txt", Toast.LENGTH_SHORT).show();

        Log.e("SD", getString(R.string.err_file)+" lovers.txt");

    }
}

//parte Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
     @Override
     public boolean onOptionsItemSelected(MenuItem item) {
        try{
         OutputStreamWriter osw = new OutputStreamWriter(openFileOutput(nFileColors, Context.MODE_PRIVATE));

        EditText edtName = findViewById(R.id.edtName);

        switch (item.getTitle().toString()){
            case "Red":
                edtName.setTextColor(getResources().getColor(R.color.Red));
                osw.write("R");
                break;
            case "Green":
                edtName.setTextColor(getResources().getColor(R.color.Green));
                osw.write("G");
                break;
            case "Blue":
                edtName.setTextColor(getResources().getColor(R.color.Blue));
                osw.write("B");
                break;
        }
         osw.close();
        return true;
        }catch (Exception e){
            Toast.makeText(this,R.string.colors_Error,Toast.LENGTH_LONG).show();
            Log.e("INTERNA", R.string.err_file+nFileColors);
            return false;
        }
     }

//parte Colores

    public void setColorName(){
        try {
            EditText edtName = findViewById(R.id.edtName);
            OutputStreamWriter osw = new OutputStreamWriter(openFileOutput(nFileColors, Context.MODE_APPEND));
            BufferedReader br = new BufferedReader(new InputStreamReader(openFileInput(nFileColors)));
            String linha="";
            while ((linha = br.readLine()) != null){
                switch (linha){
                    case "R":
                        edtName.setTextColor(getResources().getColor(R.color.Red));
                        break;
                    case "G":
                        edtName.setTextColor(getResources().getColor(R.color.Green));
                        break;
                    case "B":
                        edtName.setTextColor(getResources().getColor(R.color.Blue));
                        break;
                }
            }
            br.close();
        } catch (Exception ex) {
            Toast.makeText(this, R.string.colors_Error, Toast.LENGTH_SHORT).show();
            Log.e("INTERNA", getString(R.string.colors_Error)+nFileColors);
        }
    }

    ///Parte Chamar

    public void onbtnCall(View v){
        EditText edtPhone =findViewById(R.id.edtPhon);
        if (edtPhone.getText().toString().equals("")){
            Toast.makeText(this,R.string.call_empty,Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT>=23){
            int permiso = checkSelfPermission(Manifest.permission.CALL_PHONE);
            if (permiso ==PackageManager.PERMISSION_GRANTED){
                chamarTelefono();
            }
            else{
                T1F_a15manuelmd.this.requestPermissions( new String[]{Manifest.permission.CALL_PHONE},CODIGO_IDENTIFICADOR);
            }
        }else
            chamarTelefono();
    }


    @SuppressLint("MissingPermission")
    private void chamarTelefono(){
        EditText edtPhone =findViewById(R.id.edtPhon);
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:"+edtPhone.getText().toString()));
        startActivity(callIntent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case CODIGO_IDENTIFICADOR: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    chamarTelefono();
                } else {
                    Toast.makeText(this,R.string.call_permissons,Toast.LENGTH_LONG).show();
                }
                Toast.makeText(this,R.string.call_permissons,Toast.LENGTH_LONG).show();
                return;
            }
        }
    }
}
