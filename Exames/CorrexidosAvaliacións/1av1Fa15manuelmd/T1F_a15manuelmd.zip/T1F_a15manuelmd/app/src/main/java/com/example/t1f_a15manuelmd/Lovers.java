package com.example.t1f_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class Lovers extends AppCompatActivity {
static  String[] arMeses={"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Setiembre","Octubre","Noviembre","Diciembre"};
    public static  String nomeFicheiro = "lovers.txt";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lovers);
        Spinner spMes = findViewById(R.id.spMeses);
        spMes.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arMeses));
    }

public void onBtnAddtFile(View v ){
    EditText edtLovers =findViewById(R.id.edtLovers);
    Spinner spMes = findViewById(R.id.spMeses);
    if (edtLovers.getText().toString().equals("")){
        Toast.makeText(this,R.string.lovers_empty,Toast.LENGTH_LONG).show();
        return;
    }
        try {
            File rutaCompleta=new File(getFilesDir()+"/"+T1F_a15manuelmd.name);
            rutaCompleta.mkdir();
            OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(rutaCompleta+"/"+nomeFicheiro, true));
            osw.write(spMes.getSelectedItem().toString()+" "+edtLovers.getText().toString()+"\n");
            osw.close();
            Log.i("SD", getString(R.string.saved_on)+rutaCompleta+"/"+nomeFicheiro);
            edtLovers.setText("");
        } catch (Exception ex) {
            Log.e("SD", getString(R.string.err_file)+" lovers.txt");
        }
    }
}
