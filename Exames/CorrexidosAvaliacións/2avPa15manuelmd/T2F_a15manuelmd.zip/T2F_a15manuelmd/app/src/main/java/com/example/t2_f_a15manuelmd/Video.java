package com.example.t2_f_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.MediaController;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Video extends AppCompatActivity {
    private static final int CODIGO_IDENTIFICADOR = 2;
    private final int REQUEST_CODE_GRAVACION_OK = 1;
    boolean sdDisponhible = false;
    boolean sdAccesoEscritura = false;
    final private String nomeVideo = "video.mp4";
    final private String nomeFoto = "foto.jpg";
    File rutaVideos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        VideoView vv = findViewById(R.id.videoView);
        MediaController controller = new MediaController(this);
        vv.setMediaController(controller);
        try {
            rutaVideos = new File(getExternalFilesDir(null).getAbsolutePath() + "/VIDEO/"+MainActivity.nomUsuario);
            rutaVideos.mkdirs();
        }catch (Exception e){e.printStackTrace();}

        // rutaVideos = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
        }
        cargarSpinner();
        comprobarEstadoSD();

    }

    public void comprobarEstadoSD() {
        String estado = Environment.getExternalStorageState();
        Log.e("SD", estado);

        if (estado.equals(Environment.MEDIA_MOUNTED)) {
            sdDisponhible = true;
            sdAccesoEscritura = true;
        } else if (estado.equals(Environment.MEDIA_MOUNTED_READ_ONLY))
            sdDisponhible = true;
    }


    public void gravarVideo(View v) {
        if (!sdDisponhible) {
            Toast.makeText(this, "sd non montada", Toast.LENGTH_LONG).show();
            return;
        }
        if (!sdAccesoEscritura) {
            Toast.makeText(this, "sd non esta en modo escritura", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            cargarSpinner();

                Intent intento = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                String timeStamp = DateFormat.getDateTimeInstance().format(
                        new Date()).replaceAll(":", "").replaceAll("/", "_")
                        .replaceAll(" ", "_");

                File fdest = new File(rutaVideos + "/Video_" + timeStamp + ".mp4");
                intento.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(fdest));
                startActivityForResult(intento, REQUEST_CODE_GRAVACION_OK);


        } catch (Exception e) {
            Toast.makeText(this, "necesitas permisos", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        cargarSpinner();
    }


    public void cargarSpinner() {
        TextView tvRura = findViewById(R.id.tvRuta);
        tvRura.setText(rutaVideos.getAbsolutePath());

        final Spinner sp = findViewById(R.id.spVideo);

        ArrayList<String> arSons = new ArrayList<>();
        for (File f : rutaVideos.listFiles())
            arSons.add(f.getName());
        ArrayAdapter adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arSons);
        sp.setAdapter(adaptador);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                VideoView vv = findViewById(R.id.videoView);
                Uri videoUri = Uri.fromFile(new File(rutaVideos + "/" + sp.getSelectedItem().toString()));
                vv.setVideoURI(videoUri);
                //vv.start();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}
