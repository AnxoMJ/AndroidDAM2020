package com.example.t2_f_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Salary extends AppCompatActivity {

    private BasedeDatos base;
    SQLiteDatabase sqlLiteDB;
    boolean sdDisponhible = false;
    boolean sdAccesoEscritura = false;
    File dirFicheiroSD;
    File rutaCompleta;
    public static String nomeFicheiro = "salarios.txt";
    static ArrayList<ObSalarios> arSal = new ArrayList<ObSalarios>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salary);
        base = new BasedeDatos(getApplicationContext());
        sqlLiteDB = base.getWritableDatabase();

    }


    public void btnXml(View v) {
        parseXML();
    }


    public void parseXML() {
        try {
            descargarXML();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "error descarga", Toast.LENGTH_SHORT).show();
        }
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        InputStream is = null;
        try {
            //is = getAssets().open("ud4_01_arquivo.xml");
            File rutaArquivo = new File(getFilesDir().getAbsolutePath() + "/salarios.xml");
            is = new FileInputStream(rutaArquivo);
            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(is, "UTF-8");

            int evento = parser.nextTag();
            ObSalarios salario = null;
            arSal = new ArrayList<>();
            while (evento != XmlPullParser.END_DOCUMENT) {
                if (evento == XmlPullParser.START_TAG) {
                    if (parser.getName().equals("salary")) {    // Un novo contacto
                        salario = new ObSalarios();
                        int totalSal = 0;
                        evento = parser.nextTag();    // Pasamos a <mes>
                        salario.setMonth(parser.nextText());
                        evento = parser.nextTag();    // Pasamos a <salario>
                        totalSal = Integer.valueOf(parser.nextText());
                        while (evento != XmlPullParser.END_TAG) {
                            try {
                                evento = parser.nextTag();    // Pasamos a <tel>
                                totalSal += Integer.valueOf(parser.nextText());
                            } catch (Exception e) {
                            }

                        }
                        salario.setTotal_salary(totalSal);
                    }
                }
                if (evento == XmlPullParser.END_TAG) {
                    if (parser.getName().equals("salary")) {    // Un novo contacto
                        arSal.add(salario);
                    }
                }

                evento = parser.next();
            }

            is.close();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "error procesando o xml", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

        TextView edt = findViewById(R.id.tvSal);
        edt.setText("");

        for (ObSalarios s : arSal) {
            // edt.append(s.getMonth() + "\n");
            //edt.append(String.valueOf(s.getTotal_salary() + "\n"));
            try {
                sqlLiteDB.execSQL("INSERT INTO SALARY (month,total_salary) VALUES ('" + s.getMonth() + "','" + s.getTotal_salary() + "')");
            } catch (Exception e) {
            }

        }


    }

    public void descargarXML() {
        try {
            Thread thread = new Thread() {

                @Override
                public void run() {
                    try {
                        descargarArquivo();
                    } catch (Exception e) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "error na descarga, existe o ficheiro?", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            };

            thread.start();
        } catch (Exception e) {
            Toast.makeText(this, "error na descarga, existe o ficheiro?", Toast.LENGTH_SHORT).show();
        }

    }

    private void descargarArquivo() throws Exception {
        URL url = null;
        try {
            EditText edtRuta = findViewById(R.id.edtUrl);
            url = new URL(edtRuta.getText().toString());
        } catch (MalformedURLException e1) {
            // TODO Auto-generated catch block

            e1.printStackTrace();
            return;
        }

        HttpURLConnection conn = null;

        File rutaArquivo = new File(getFilesDir().getAbsolutePath() + "/salarios.xml");
        try {

            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);    /* milliseconds */
            conn.setConnectTimeout(15000);  /* milliseconds */
            conn.setRequestMethod("POST");
            conn.setDoInput(true);            /* Indicamos que a conexión vai recibir datos */

            conn.connect();

            int response = conn.getResponseCode();
            if (response != HttpURLConnection.HTTP_OK) {
                return;
            }
            OutputStream os = new FileOutputStream(rutaArquivo);
            InputStream in = conn.getInputStream();
            byte data[] = new byte[1024];    // Buffer a utilizar
            int count;
            while ((count = in.read(data)) != -1) {
                os.write(data, 0, count);
            }
            os.flush();
            os.close();
            in.close();
            conn.disconnect();
            Log.i("COMUNICACION", "ACABO");
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    ///mostrar sal
    public void showsal(View v) {
        TextView tv = findViewById(R.id.tvSal);
        tv.setText("");
        tv.append("Total_Salary      Month\n");
        for (ObSalarios s : arSal) {
            tv.append(String.valueOf(s.getTotal_salary() + "                 " + s.getMonth() + "\n"));
        }
    }
    ///sal2filel
    public void sal2filel(View v){
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }*/
        comprobarEstadoSD();
        rutaCompleta =new File (getExternalFilesDir(null).getAbsolutePath()+"/"+MainActivity.nomUsuario+".txt");
        ArrayList<ObSalarios>arsal2=new ArrayList<>();
        Cursor cursor = sqlLiteDB.rawQuery("select * from SALARY", null);
        if (sdAccesoEscritura) {

            try {
                OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(rutaCompleta, true));

                osw.write( "Total_Salary    Month\n");
                if (cursor.moveToFirst()) {                // Se non ten datos xa non entra
                    while (!cursor.isAfterLast()) {     // Quédase no bucle ata que remata de percorrer o cursor. Fixarse que leva un ! (not) diante
                        String month = cursor.getString(0);
                        int sal = cursor.getInt(1);
                        arsal2.add(new ObSalarios(month,sal));
                        osw.write(sal+"           "+month + "\n");
                        cursor.moveToNext();
                    }
                }

                Log.i("crerado",getExternalFilesDir(null).getAbsolutePath()+"/"+MainActivity.nomUsuario+".txt");
                osw.close();


            } catch (Exception ex) {
                Log.e("SD", "Error escribindo no ficheiro");
            }
        } else
            Toast.makeText(this, "A tarxeta SD non está en modo acceso escritura", Toast.LENGTH_SHORT).show();


    }
    public void comprobarEstadoSD() {
        String estado = Environment.getExternalStorageState();
        Log.e("SD", estado);

        if (estado.equals(Environment.MEDIA_MOUNTED)) {
            sdDisponhible = true;
            sdAccesoEscritura = true;
        } else if (estado.equals(Environment.MEDIA_MOUNTED_READ_ONLY))
            sdDisponhible = true;
    }

}
