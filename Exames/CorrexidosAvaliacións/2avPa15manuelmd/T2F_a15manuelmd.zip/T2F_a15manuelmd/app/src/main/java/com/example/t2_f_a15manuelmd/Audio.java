package com.example.t2_f_a15manuelmd;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.DialogInterface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Audio extends AppCompatActivity {
    private MediaRecorder mediaRecorder;
    private String arquivoGravar;
    File fAudio;
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }
        cargarSpinner();
        mediaPlayer = new MediaPlayer();
    }

    public void cargarSpinner() {
        Spinner sp = findViewById(R.id.spAudio);
        fAudio = new File(getExternalFilesDir(null).getAbsolutePath() + "/AUDIO/" + MainActivity.nomUsuario);
        ArrayList<String> arSons = new ArrayList<>();
        for (File f : fAudio.listFiles())
            arSons.add(f.getName());
        ArrayAdapter adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arSons);
        sp.setAdapter(adaptador);
        xestionarEventos();
    }

    public void btRepro(View v) {
        if (mediaPlayer != null)
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
                mediaPlayer.release();
            }

        try {
            // mediaPlayer.setDataSource(arquivoGravar);
            mediaPlayer = new MediaPlayer();
            Spinner sp = findViewById(R.id.spAudio);
            Uri uri = Uri.parse(fAudio + "/" + sp.getSelectedItem().toString());

            mediaPlayer.setDataSource(getApplicationContext(), uri);
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.prepare();
            mediaPlayer.start();

        } catch (Exception e) {
            // Toast.makeText(getApplicationContext(), "ERRO:" + e.getMessage(), Toast.LENGTH_LONG).show();
            Log.e("ErrorRepro",e.getMessage());
        }
    }

    public void btParar(View v) {
        if (mediaPlayer != null)
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
    }


    private void xestionarEventos() {

        Button btnGravar = (Button) findViewById(R.id.btGravar);
        btnGravar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                }
                String timeStamp = DateFormat.getDateTimeInstance().format(
                        new Date()).replaceAll(":", "").replaceAll("/", "_")
                        .replaceAll(" ", "_");
                try {
                    mediaRecorder = new MediaRecorder();
                    arquivoGravar = fAudio + "/" + timeStamp + ".3gp";
                    mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                    mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                    mediaRecorder.setMaxDuration(7000);
                    mediaRecorder.setAudioEncodingBitRate(32768);
                    mediaRecorder.setAudioSamplingRate(8000); // No emulador só 8000 coma
                    mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                    mediaRecorder.setOutputFile(arquivoGravar);

                    mediaRecorder.prepare();
                    mediaRecorder.start();
                    cargarSpinner();

                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    mediaRecorder.reset();
                }
                abrirDialogo("GRAVAR");

                cargarSpinner();
            }
        });


    }


    private void abrirDialogo(String tipo) {
        if (tipo == "GRAVAR") {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                    .setMessage("GRAVANDO").setPositiveButton(
                            "PREME PARA PARAR",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    // TODO Auto-generated method stub
                                    try {
                                        mediaRecorder.stop();
                                        mediaRecorder.release();
                                        mediaRecorder = null;
                                    } catch (Exception e) {
                                    }

                                }
                            }).setCancelable(false);
            dialog.show();
        }


    }
}

