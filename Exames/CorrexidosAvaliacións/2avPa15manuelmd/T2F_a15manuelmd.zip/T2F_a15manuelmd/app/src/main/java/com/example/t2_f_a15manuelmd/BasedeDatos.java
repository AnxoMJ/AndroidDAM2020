package com.example.t2_f_a15manuelmd;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BasedeDatos extends SQLiteOpenHelper{
    public final static String NOME_BD="salaries.db";
    public final static int VERSION_BD=1;
    public SQLiteDatabase sqlLiteDB;
    public BasedeDatos(Context context) {
        super(context, NOME_BD, null, VERSION_BD);
    }

    private String CREAR_TABOA_AULAS ="CREATE TABLE SALARY ( " +
            "month  VARCHAR(15) PRIMARY KEY ," +
            "total_salary REAL  NOT NULL)";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREAR_TABOA_AULAS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}