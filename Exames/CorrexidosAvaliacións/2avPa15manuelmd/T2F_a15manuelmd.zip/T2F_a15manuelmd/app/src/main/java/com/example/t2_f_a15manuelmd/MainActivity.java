package com.example.t2_f_a15manuelmd;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;


public class MainActivity extends AppCompatActivity {
    private static final int CODIGO_IDENTIFICADOR = 1;
    SharedPreferences sharedpref;
    EditText edtTlf;
    static String nomUsuario="";
    static File fAudio=null;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtTlf=findViewById(R.id.edtPhone);
        sharedpref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        establecerCor();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_pref, menu);
        return true;
    }
    @Override
    protected void onResume() {
        super.onResume();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        SharedPreferences.Editor editor = sharedpref.edit();
        switch (item.getItemId()) {
            case R.id.azul:
                editor.putString("pref_color", "B");
                editor.commit();
                edtTlf.setTextColor(getResources().getColor(R.color.cazul));
                return true;

            case R.id.verde:
                editor.putString("pref_color", "G");
                edtTlf.setTextColor(getResources().getColor(R.color.cverde));
                editor.commit();
                return true;
            case R.id.vermello:
                editor.putString("pref_color", "R");
                edtTlf.setTextColor(getResources().getColor(R.color.cvermello));
                editor.commit();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void finish() {

        super.finish();
    }

///sacase a cor
    public void establecerCor(){
        switch (sharedpref.getString("pref_color","R")){
            case "B":
                edtTlf.setTextColor(getResources().getColor(R.color.cazul));
                break;
            case "G":
                edtTlf.setTextColor(getResources().getColor(R.color.cverde));
                break;
            case "R":
                edtTlf.setTextColor(getResources().getColor(R.color.cvermello));
                break;
        }
    }

    public void onClicSalary(View v) {
        EditText edtnome = findViewById(R.id.edtNome);
        if (edtnome.getText().toString().equals("")) {
            Toast.makeText(this, R.string.val, Toast.LENGTH_LONG).show();
            return;
        }
        nomUsuario=edtnome.getText().toString();
        Intent intent = new Intent(this, Salary.class);
        startActivity(intent);
    }

    public void onClicVideo(View v) {
        EditText edtnome = findViewById(R.id.edtNome);
        if (edtnome.getText().toString().equals("")) {
            Toast.makeText(this,R.string.val, Toast.LENGTH_LONG).show();
            return;
        }
        nomUsuario=edtnome.getText().toString();
        Intent intent = new Intent(this, Video.class);
        startActivity(intent);
    }



//parte telefono

    public void onClicCall(View v) {
        if (edtTlf.getText().toString().equals("")) {
            Toast.makeText(this, R.string.sen_tlf, Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            int permiso = checkSelfPermission(Manifest.permission.CALL_PHONE);
            if (permiso == PackageManager.PERMISSION_GRANTED) {
                chamarTelefono();
            } else {
                MainActivity.this.requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, CODIGO_IDENTIFICADOR);
            }

        } else
            chamarTelefono();
    }

    @SuppressLint("MissingPermission")
    private void chamarTelefono() {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + edtTlf.getText().toString()));
        startActivity(callIntent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case CODIGO_IDENTIFICADOR: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    chamarTelefono();
                } else {

                    Toast.makeText(this, R.string.perm_tlf, Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }
    //parte audio
    public void onClicAudio(View v) {
        EditText edtnome = findViewById(R.id.edtNome);
        if (edtnome.getText().toString().equals("")) {
            Toast.makeText(this,R.string.val, Toast.LENGTH_LONG).show();
            return;
        }
        nomUsuario=edtnome.getText().toString();
       fAudio= new File(getExternalFilesDir(null).getAbsolutePath()+"/AUDIO/"+nomUsuario);
        fAudio.mkdirs();
    ///copiar a musica
    try {
        //File ruta = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        String[] as = {"Bruce Springsteen - Dream Baby Dream.mp3", "Rachel Portman.mp3"};
        for (String s : as) {
            File arquivo_destino = new File(fAudio,s);
            InputStream is = getAssets().open(s);
            FileOutputStream fos_sdcard = new FileOutputStream(arquivo_destino);
            int tamRead;
            byte[] buffer = new byte[2024];
            while((tamRead = is.read(buffer))>0){
                fos_sdcard.write(buffer, 0, tamRead);
            }
            is.close();
            fos_sdcard.close();
        }


        } catch(Exception e){
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        Intent intent = new Intent(this,Audio.class);
        startActivity(intent);
    }
}
