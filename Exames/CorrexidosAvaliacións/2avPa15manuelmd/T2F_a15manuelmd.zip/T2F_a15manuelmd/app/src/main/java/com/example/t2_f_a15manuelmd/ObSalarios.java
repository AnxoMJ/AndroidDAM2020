package com.example.t2_f_a15manuelmd;

public class ObSalarios {
    String month;
    int total_salary;

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public int getTotal_salary() {
        return total_salary;
    }

    public void setTotal_salary(int total_salary) {
        this.total_salary = total_salary;
    }

    public ObSalarios(String month, int total_salary) {
        this.month = month;
        this.total_salary = total_salary;
    }
    public ObSalarios() {
    }
}
