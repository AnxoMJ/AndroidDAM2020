package com.example.de_a15manuelmd;

public class OEmployes {
    int empno;
    String ename;
    long home;
    long mobile;
    int deptno;

    public int getEmpno() {
        return empno;
    }

    public void setEmpno(int empno) {
        this.empno = empno;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public long getHome() {
        return home;
    }

    public void setHome(int home) {
        this.home = home;
    }

    public long getMobile() {
        return mobile;
    }

    public void setMobile(int mobile) {
        this.mobile = mobile;
    }

    public int getDeptno() {
        return deptno;
    }

    public void setDeptno(int deptno) {
        this.deptno = deptno;
    }

    @Override
    public String toString() {
        String cadea = "---Empregado---" +
                "\nempno: " + empno +
                "\nename: " + ename +
                "\ndeptno: " + deptno;
        if (home != 0)
            cadea += "\nhome: " + home;
        if (mobile != 0)
            cadea += "\nmobile: " + mobile
                    + "\n---------------------------";
        return cadea;
    }
}
