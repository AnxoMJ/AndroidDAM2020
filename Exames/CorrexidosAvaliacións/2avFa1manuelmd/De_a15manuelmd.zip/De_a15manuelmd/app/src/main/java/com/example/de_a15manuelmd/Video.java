package com.example.de_a15manuelmd;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URI;
import java.util.ArrayList;

public class Video extends AppCompatActivity {
    private static final int CODIGO_IDENTIFICADOR = 2;
    private static final int REQUEST_CODE_CAMARA = 3;
    private static final int REQUEST_CODE_GRAVACION_OK = 4;
    File rutaVideo;
    Spinner spv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        //rutaVideo=new File(getExternalFilesDir(null)+"/a15manuelmd/Videos");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Video.this.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 22);
        }
        /*rutaVideo=new File(Environment.getExternalStorageDirectory()+"/a15manuelmd/Videos" );
        rutaVideo.mkdirs();
        spv=findViewById(R.id.spVid);

        cargarSp();*/
    }

    @Override

    public void onRequestPermissionsResult(int requestCode,

                                           String permissions[], int[] grantResults) {

        switch (requestCode) {

            case CODIGO_IDENTIFICADOR: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    camara();
                } else {
                    Toast.makeText(this, "É NECESARIO O PERMISO PARA USAR A CÁMARA", Toast.LENGTH_LONG).show();
                }
                return;
            }
            case 22: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    rutaVideo = new File(Environment.getExternalStorageDirectory() + "/MM/a15manuelmd/Videos");
                    rutaVideo.mkdirs();
                    spv = findViewById(R.id.spVid);
                    cargarSp();
                } else {
                    Toast.makeText(this, "Non se pode continuar sen o permiso de escritura na sdcad", Toast.LENGTH_LONG).show();
                    finish();
                }
                return;
            }
        }
    }

    public void btGravarV(View v) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Video.this.requestPermissions(new String[]{Manifest.permission.CAMERA}, CODIGO_IDENTIFICADOR);
        }

    }

    public void camara() {
        Intent intento = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        int num = rutaVideo.listFiles().length;
        intento.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(rutaVideo + "/video_" + num + ".mp4")));


        startActivityForResult(intento, REQUEST_CODE_GRAVACION_OK);
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            cargarSp();
        } catch (Exception e) {
        }

    }

    public void btReproV(View v) {
        if (spv.getSelectedItem() == null)
            return;
        MediaController controller = new MediaController(this);

        VideoView videoview = (VideoView) findViewById(R.id.vidV);
        videoview.setMediaController(controller);
        videoview.setVideoURI(Uri.fromFile(new File(rutaVideo + "/" + spv.getSelectedItem().toString())));
        videoview.start();
    }

    public void cargarSp() {
        ArrayList<String> ars = new ArrayList<>();
        for (File f : rutaVideo.listFiles()) {
            ars.add(f.getName());
        }
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ars);
        spv.setAdapter(adaptador);
    }
}
