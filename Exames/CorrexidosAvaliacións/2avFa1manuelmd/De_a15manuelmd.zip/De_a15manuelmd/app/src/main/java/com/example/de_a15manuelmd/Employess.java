package com.example.de_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Employess extends AppCompatActivity {
    TextView tvDep;
    EditText edtURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employess);

        tvDep = findViewById(R.id.edtDep);
        edtURL = findViewById(R.id.edtURL);
        cargarTV();

    }

    public void cargarTV() {
        tvDep.setText("nDep: " + MainActivity.depSel.deptno + "\nnome: " + MainActivity.depSel.dname);
    }

    public void btSave2(View v) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    descargarArquivo();
                    lerArquivo();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void lerArquivo() throws IOException, XmlPullParserException {
        ArrayList<OEmployes> ardep = new ArrayList<>();
        InputStream is = new FileInputStream(new File(getFilesDir() + "/emp.xml"));
        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(is, "UTF-8");
        int evento = parser.nextTag();
        OEmployes obxeto = null;
        while (evento != XmlPullParser.END_DOCUMENT) {
            if (evento == XmlPullParser.START_TAG) {
                if (parser.getName().equals("emp")) {    // Un novo contacto
                    obxeto = new OEmployes();
                    evento = parser.nextTag();    // Pasamos a <nome>
                    //  Log.i("saco",parser.nextText());
                    obxeto.empno = (Integer.valueOf(parser.nextText()));
                    evento = parser.nextTag();    // Pasamos a <dir>
                    //Log.i("saco",parser.nextText());
                    obxeto.ename = (parser.nextText());
                    evento = parser.nextTag();
                    //Log.i("tag",parser.getAttributeValue(0));
                    int cont = 0;
                    while (cont < 4) {
                        try {
                            switch (parser.getAttributeValue(0)) {
                                case "home":
                                    obxeto.home = Integer.valueOf(parser.nextText());
                                    evento = parser.nextTag();
                                    break;
                                case "mobile":
                                    obxeto.mobile = Integer.valueOf(parser.nextText());
                                    evento = parser.nextTag();
                                    break;
                            }
                        } catch (Exception e) {
                            //e.printStackTrace();
                        }
                        cont++;
                    }
                    obxeto.deptno = (Integer.valueOf(parser.nextText()));
                    ardep.add(obxeto);
                }
            }
            evento = parser.next();
        }


        is.close();
        for (OEmployes odpo : ardep) {
            try {
                if (MainActivity.depSel.deptno == odpo.deptno) {
                    Log.i("infoGardado", odpo.toString());
                    MainActivity.base.engadirEmp(odpo);
                }
                //MainActivity.base.engadirDep(odpo);
                //Log.i("infoGardado",odpo.toString());
            } catch (Exception e) {
                Log.i("baseDatos", "elemento empregado repetido");
                // e.printStackTrace();
            }
        }
    }


    private void descargarArquivo() {

        URL url = null;

        try {
            url = new URL(edtURL.getText().toString());

        } catch (MalformedURLException e1) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), "Ficheiro non descargado", Toast.LENGTH_LONG).show();
                }
            });
            e1.printStackTrace();
            return;
        }


        HttpURLConnection conn = null;
        String rutaArquivo = (getFilesDir() + "/emp.xml");
        try {
            conn = (HttpURLConnection) url.openConnection();

            conn.setReadTimeout(10000);    /* milliseconds */

            conn.setConnectTimeout(15000);  /* milliseconds */

            conn.setRequestMethod("POST");

            conn.setDoInput(true);            /* Indicamos que a conexión vai recibir datos */

            conn.connect();

            int response = conn.getResponseCode();

            if (response != HttpURLConnection.HTTP_OK) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "Ficheiro non descargado", Toast.LENGTH_LONG).show();
                    }
                });
                return;
            }

            OutputStream os = new FileOutputStream(rutaArquivo);

            InputStream in = conn.getInputStream();

            byte data[] = new byte[1024];    // Buffer a utilizar

            int count;

            while ((count = in.read(data)) != -1) {

                os.write(data, 0, count);
            }

            os.flush();

            os.close();

            in.close();

            conn.disconnect();

            Log.i("COMUNICACION", "ACABO");

        } catch (Exception e) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), "Ficheiro non descargado", Toast.LENGTH_LONG).show();
                }
            });
            Log.e("COMUNICACION", e.getMessage());
        }
    }
}
