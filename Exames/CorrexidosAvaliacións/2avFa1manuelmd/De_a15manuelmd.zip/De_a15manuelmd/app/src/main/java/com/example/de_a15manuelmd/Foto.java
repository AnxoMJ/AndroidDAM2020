package com.example.de_a15manuelmd;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class Foto extends AppCompatActivity {
    private static final int REQUEST_CODE_CAMARA = 1;
    private static final int CODIGO_IDENTIFICADOR = 2;
    File rutaFoto;
    Spinner spFot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foto);
        // rutaFoto=new File(getExternalFilesDir(null)+"/a15manuelmd/Fotos");
        //rutaFoto.mkdirs();
        spFot = findViewById(R.id.spFot);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Foto.this.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 22);
        }
        //cargarSp();
    }

    @Override

    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case CODIGO_IDENTIFICADOR: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    video();
                } else {
                    Toast.makeText(this, "É NECESARIO O PERMISO PARA USAR A CÁMARA", Toast.LENGTH_LONG).show();

                }
                return;
            }
            case 22: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    rutaFoto = new File(Environment.getExternalStorageDirectory() + "/MM/a15manuelmd/Fotos");
                    rutaFoto.mkdirs();
                    cargarSp();
                } else {
                    Toast.makeText(this, "Non se pode continuar sen o permiso de escritura na sdcad", Toast.LENGTH_LONG).show();
                    finish();
                }
                return;
            }
        }
    }

    public void btGravarF(View v) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Foto.this.requestPermissions(new String[]{Manifest.permission.CAMERA}, CODIGO_IDENTIFICADOR);
        }
    }

    public void video() {
        Intent intento = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        startActivityForResult(intento, REQUEST_CODE_CAMARA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);
            if (data == null)
                return;
            int num = rutaFoto.listFiles().length;
            Bitmap bm = (Bitmap) data.getExtras().get("data");
            bm.compress(Bitmap.CompressFormat.PNG, 1, new FileOutputStream(new File(rutaFoto + "/foto_" + num + ".PNG")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        cargarSp();
    }

    public void btReproF(View v) {
        if (spFot.getSelectedItem() == null)
            return;
        ImageView imv = findViewById(R.id.imvFot);
        Bitmap bitmap = BitmapFactory.decodeFile(rutaFoto + "/" + spFot.getSelectedItem().toString());
        imv.setImageBitmap(bitmap);
    }

    public void cargarSp() {
        ArrayList<String> ars = new ArrayList<>();
        for (File f : rutaFoto.listFiles()) {
            ars.add(f.getName());
        }
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ars);

        spFot.setAdapter(adaptador);
    }
}
