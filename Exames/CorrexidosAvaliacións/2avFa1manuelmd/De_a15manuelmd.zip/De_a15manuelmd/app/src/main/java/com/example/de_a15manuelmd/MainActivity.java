package com.example.de_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.Xml;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final int CODIGO_IDENTIFICADOR = 1;
    private SharedPreferences preferencias;
    EditText phon;
    static BaseDatos base;
    Spinner spdeps;
    ListView lvemp;
    static ODep depSel;
    static URL urlDEP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        phon = findViewById(R.id.edtPhone);
        lvemp = findViewById(R.id.lvEmpregados);
        try {
            ////cambia esta url para o ficheiro dos Departamentos
            urlDEP=new URL("https://informatica.iessanclemente.net/pmdm/dept.xml");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        preferencias = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        cargColor();
        base = new BaseDatos(this);
        base.sqlLiteDB = base.getWritableDatabase();
        spdeps = findViewById(R.id.spDep);
        todo();
        cargarSp();
        actualizarLVemp();
        spdeps.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                actualizarDatosvist();
                actualizarLVemp();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        lvemp.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "posicion: " + position + "\nten: " + lvemp.getItemAtPosition(position), Toast.LENGTH_LONG).show();
                ODep odep = (ODep) spdeps.getSelectedItem();
                OutputStreamWriter osw = null;
                try {
                    osw = new OutputStreamWriter(openFileOutput(odep.deptno + "_" + position + ".txt", Context.MODE_PRIVATE));
                    osw.write(lvemp.getItemAtPosition(position).toString());

                    osw.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void actualizarLVemp() {
        if (spdeps.getSelectedItem() == null)
            return;
        ODep odep = (ODep) spdeps.getSelectedItem();
        ArrayAdapter<OEmployes> adaptador = new ArrayAdapter<OEmployes>(this, android.R.layout.simple_list_item_1, base.obterEmps(odep.deptno));
        lvemp.setAdapter(adaptador);
    }


    public void actualizarDatosvist() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (spdeps.getSelectedItem() == null)
                    return;
                phon.setText("");
                ODep odep = (ODep) spdeps.getSelectedItem();
                if (odep.tel != 0)
                    phon.setText(String.valueOf(odep.tel));
            }
        });
    }

    @Override

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.u5_01__menus, menu);
        return true;
    }

    public void todo() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                descargarArquivo();
                try {
                    lerArquivo();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            cargColor();
                            cargarSp();
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }).start();
    }

    public void cargarSp() {

        ArrayAdapter<ODep> adaptador = new ArrayAdapter<ODep>(this, android.R.layout.simple_spinner_item, base.obterDeps());

        spdeps.setAdapter(adaptador);
    }

    private void lerArquivo() throws IOException, XmlPullParserException {
        ArrayList<ODep> ardep = new ArrayList<>();


        InputStream is = new FileInputStream(new File(getFilesDir() + "/dep.xml"));


        XmlPullParser parser = Xml.newPullParser();

        parser.setInput(is, "UTF-8");


        int evento = parser.nextTag();

        ODep obxeto = null;


        while (evento != XmlPullParser.END_DOCUMENT) {

            if (evento == XmlPullParser.START_TAG) {

                if (parser.getName().equals("dept")) {    // Un novo contacto

                    obxeto = new ODep();

                    evento = parser.nextTag();    // Pasamos a <nome>
                    //Log.i("saco",parser.nextText());

                    obxeto.deptno = (Integer.valueOf(parser.nextText()));

                    evento = parser.nextTag();    // Pasamos a <dir>
                    //Log.i("saco",parser.nextText());
                    obxeto.dname = (parser.nextText());


                    ardep.add(obxeto);
                }

            }

            if (evento == XmlPullParser.END_TAG) {

                if (parser.getName().equals("contacto")) {    // Un novo contacto

                    // contactos.add(contacto);

                }

            }


            evento = parser.next();

        }


        is.close();
        for (ODep odpo : ardep) {
            try {
                MainActivity.base.engadirDep(odpo);
                // Log.i("infoGardado",odpo.toString());
            } catch (Exception e) {
                Log.i("baseDatos", "xa existe o elemento");
                // e.printStackTrace();
            }
        }

    }

    private void descargarArquivo() {

        URL url = null;
        url=urlDEP;
        /*try {
            //url = new URL("https://informatica.iessanclemente.net/pmdm/dept.xml");
            //url=urlDEP;
        } catch (MalformedURLException e1) {

            // TODO Auto-generated catch block

            e1.printStackTrace();
            return;
        }*/
        HttpURLConnection conn = null;
        String rutaArquivo = (getFilesDir() + "/dep.xml");

        try {

            conn = (HttpURLConnection) url.openConnection();

            conn.setReadTimeout(10000);    /* milliseconds */

            conn.setConnectTimeout(15000);  /* milliseconds */

            conn.setRequestMethod("POST");

            conn.setDoInput(true);            /* Indicamos que a conexión vai recibir datos */


            conn.connect();

            int response = conn.getResponseCode();

            if (response != HttpURLConnection.HTTP_OK) {

                return;

            }

            OutputStream os = new FileOutputStream(rutaArquivo);

            InputStream in = conn.getInputStream();

            byte data[] = new byte[1024];    // Buffer a utilizar

            int count;

            while ((count = in.read(data)) != -1) {

                os.write(data, 0, count);

            }

            os.flush();

            os.close();

            in.close();

            conn.disconnect();

            Log.i("COMUNICACION", "ACABO");

        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.e("COMUNICACION", e.getMessage());

        }


    }


    @Override
    protected void onResume() {
        super.onResume();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                cargColor();
                cargarSp();
                actualizarDatosvist();
            }
        });
    }

    @Override

    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        SharedPreferences.Editor editor = preferencias.edit();
        switch (id) {
            case R.id.itAzul:
                phon.setTextColor(getResources().getColor(R.color.azul));
                editor.putString("cor", "A");
                editor.commit();
                break;
            case R.id.itRosa:
                phon.setTextColor(getResources().getColor(R.color.rosa));
                editor.putString("cor", "R");
                editor.commit();
                break;
            case R.id.itAmarelo:
                phon.setTextColor(getResources().getColor(R.color.amarelo));
                editor.putString("cor", "M");
                editor.commit();
                break;


        }
        return super.onOptionsItemSelected(item);

    }

    public void cargColor() {
        switch (preferencias.getString("cor", "M")) {
            case "A":
                phon.setTextColor(getResources().getColor(R.color.azul));
                break;
            case "R":
                phon.setTextColor(getResources().getColor(R.color.rosa));
                break;
            case "M":
                phon.setTextColor(getResources().getColor(R.color.amarelo));
                break;
        }
    }

    @SuppressLint("MissingPermission")
    private void chamarTelefono() {

        Intent callIntent = new Intent(Intent.ACTION_CALL);

        callIntent.setData(Uri.parse("tel:" + phon.getText().toString()));

        startActivity(callIntent);

    }

    public void btCall(View v) {
        if (phon.getText().length() == 0) {
            Toast.makeText(this, R.string.tb, Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 23) {

            int permiso = checkSelfPermission(Manifest.permission.CALL_PHONE);

            if (permiso == PackageManager.PERMISSION_GRANTED) {

                chamarTelefono();

            } else {

                MainActivity.this.requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, CODIGO_IDENTIFICADOR);

            }


        } else
            chamarTelefono();


    }

    @Override

    public void onRequestPermissionsResult(int requestCode,

                                           String permissions[], int[] grantResults) {

        switch (requestCode) {

            case CODIGO_IDENTIFICADOR: {

                // If request is cancelled, the result arrays are empty.

                if (grantResults.length > 0

                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    chamarTelefono();

                } else {


                    Toast.makeText(this, R.string.permn, Toast.LENGTH_LONG).show();

                }

                return;

            }


            // other 'case' lines to check for other

            // permissions this app might request

        }

    }


    public void btVideo(View v) {
        Intent intent = new Intent(this, Video.class);
        startActivity(intent);
    }

    public void btFoto(View v) {
        Intent intent = new Intent(this, Foto.class);
        startActivity(intent);
    }

    public void btSave(View v) {
        try {
            if (phon.getText().length() == 0) {
                Toast.makeText(this, R.string.tb, Toast.LENGTH_LONG).show();
                return;
            }

            ODep depo = (ODep) spdeps.getSelectedItem();
            depo.tel = Long.valueOf(phon.getText().toString());
            base.modificarDep(depo);


        }catch (Exception e){
            actualizarDatosvist();
            Toast.makeText(this, "Número non válido ou demasiado longo(solo podes engadir numeros a base)", Toast.LENGTH_LONG).show();
        }

    }

    public void btEmployes(View v) {
        depSel = (ODep) spdeps.getSelectedItem();
        Intent intent = new Intent(this, Employess.class);
        startActivity(intent);
    }
}
