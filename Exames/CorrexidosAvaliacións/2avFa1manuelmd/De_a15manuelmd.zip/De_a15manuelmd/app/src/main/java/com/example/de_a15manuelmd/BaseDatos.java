package com.example.de_a15manuelmd;

import java.util.ArrayList;


import android.content.ContentValues;

import android.content.Context;

import android.database.Cursor;

import android.database.sqlite.SQLiteDatabase;

import android.database.sqlite.SQLiteOpenHelper;


public class BaseDatos extends SQLiteOpenHelper {


    public SQLiteDatabase sqlLiteDB;


    public final static String NOME_BD = "base";

    public final static int VERSION_BD = 1;


    private final String CONSULTAR_DEPS = "SELECT * FROM DEP";
    //private final String CONSULTAR_EMPS = "SELECT * FROM EMP where";

    private final String TABOA_DEP = "DEP";

    private String CREAR_TABOA_DEP = "CREATE TABLE DEP ( " +

            "DEPTNO  INTEGER PRIMARY KEY ," +

            "DName VARCHAR( 50 )  NOT NULL," +
            "Tel LONG" +
            ")";
    private String CREAR_TABOA_EMP = "CREATE TABLE EMP ( " +
            "EMPNO  INTEGER PRIMARY KEY ," +
            "EName VARCHAR( 50 )  NOT NULL," +
            "Home LONG," +
            "Mobile LONG," +
            "DEPTNO REFERENCES DEP(DEPTNO))";

    public ArrayList<OEmployes> obterEmps(int depno) {
        ArrayList<OEmployes> aulas_devolver = new ArrayList<OEmployes>();
        Cursor datosConsulta = sqlLiteDB.rawQuery("SELECT * FROM EMP WHERE DEPTNO=" + depno, null);
        if (datosConsulta.moveToFirst()) {
            OEmployes obxeto;
            while (!datosConsulta.isAfterLast()) {
                obxeto = new OEmployes();
                obxeto.empno = datosConsulta.getInt(0);
                obxeto.ename = datosConsulta.getString(1);
                obxeto.home = datosConsulta.getLong(2);
                obxeto.mobile = datosConsulta.getLong(3);
                obxeto.deptno = datosConsulta.getInt(4);
                aulas_devolver.add(obxeto);
                datosConsulta.moveToNext();

            }
        }
        return aulas_devolver;
    }

    public long engadirEmp(OEmployes obxeto) {
        ContentValues valores = new ContentValues();
        valores.put("EMPNO", obxeto.empno);
        valores.put("EName", obxeto.ename);
        valores.put("Home", obxeto.home);
        valores.put("Mobile", obxeto.mobile);
        valores.put("DEPTNO", obxeto.deptno);
        long id = sqlLiteDB.insert("EMP", null, valores);
        return id;
    }

    public int modificarDep(ODep obxeto) {
        ContentValues datos = new ContentValues();
        datos.put("Tel", obxeto.tel);
        String where = "DEPTNO=?";
        String[] params = new String[]{String.valueOf(obxeto.deptno)};
        int rexistrosModificados = sqlLiteDB.update(TABOA_DEP, datos, where, params);
        return rexistrosModificados;

    }

    public ArrayList<ODep> obterDeps() {
        ArrayList<ODep> aulas_devolver = new ArrayList<ODep>();
        Cursor datosConsulta = sqlLiteDB.rawQuery(CONSULTAR_DEPS, null);
        if (datosConsulta.moveToFirst()) {
            ODep obxeto;
            while (!datosConsulta.isAfterLast()) {
                obxeto = new ODep();
                obxeto.deptno = datosConsulta.getInt(0);
                obxeto.dname = datosConsulta.getString(1);
                obxeto.tel = datosConsulta.getLong(2);

                aulas_devolver.add(obxeto);
                datosConsulta.moveToNext();
            }
        }
        return aulas_devolver;
    }


    public long engadirDep(ODep obxeto) {
        ContentValues valores = new ContentValues();
        valores.put("DEPTNO", obxeto.deptno);
        valores.put("DName", obxeto.dname);
        valores.put("Tel", obxeto.tel);
        long id = sqlLiteDB.insert("DEP", null, valores);
        return id;

    }

    public BaseDatos(Context context) {
        super(context, NOME_BD, null, VERSION_BD);
    }


    @Override

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREAR_TABOA_DEP);
        db.execSQL(CREAR_TABOA_EMP);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

}