package com.example.i_5z_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;

public class MainActivity extends AppCompatActivity {
    TextView tv;
    private boolean sdWriteAccess = false;
    private final int CODIGO_ESCRITURA_SD = 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv=findViewById(R.id.tvShow);
            if (Build.VERSION.SDK_INT >= 23) {
                int permisoEscribir = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
                if (permisoEscribir == PackageManager.PERMISSION_GRANTED) {
                    sdWriteAccess = true;
                } else {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            CODIGO_ESCRITURA_SD);
                }
            } else if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                sdWriteAccess = true;
            }
    }

    public void onBotonClick(View v){

        RadioGroup rg = findViewById(R.id.rgStorage);
        EditText edtDirec=(EditText) findViewById(R.id.edtDirec);
        EditText edtFile=(EditText) findViewById(R.id.edtFile);
        EditText edtSentence=(EditText) findViewById(R.id.edtSentence);
        CheckBox cbx =(CheckBox)findViewById(R.id.cbOverWrite);
        String carpeta="";
        String fiche="";
        File rutaCarpeta=null;
        File ficheiro=null;
        boolean isRaw=false;
        if(!edtDirec.equals("")){
            carpeta="/"+edtDirec.getText().toString()+"/";
        }if(!edtFile.equals("")){
            fiche=edtFile.getText().toString();
        }

        switch (rg.getCheckedRadioButtonId()){

            case R.id.rbInternal:
                ficheiro= new File(getFilesDir().toString()+carpeta+fiche);
                rutaCarpeta= new File(getFilesDir().toString()+carpeta);
                break;
            case R.id.rbRaw:
                isRaw=true;
                break;
            case R.id.rbSD:
                if (Build.VERSION.SDK_INT >= 23) {
                    if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED );
                        sdWriteAccess = true;
                }
                if(!sdWriteAccess){
                    Toast.makeText(getApplicationContext(), "SD is not presentunmounted",Toast.LENGTH_SHORT).show();
                    return;
                }
                ficheiro=new File(Environment.getExternalStorageDirectory().toString()+carpeta+fiche);
                rutaCarpeta= new File(Environment.getExternalStorageDirectory().toString()+carpeta);
                break;
        }

        switch (v.getId()){
            case R.id.bWriteAppend:
                if (!isRaw) {
                    if (!carpeta.equals("") && !fiche.equals("")){
                        rutaCarpeta.mkdirs();
                    }
                    if (fiche.equals("")){
                        Toast.makeText(this, "You should type a file", Toast.LENGTH_SHORT).show();
                        return;
                    }else
                        tv.setText("");
                    EditText etTexto = (EditText) findViewById(R.id.edtSentence);
                    CheckBox cbSobrescribir = (CheckBox) findViewById(R.id.cbOverWrite);
                    try {
                        OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(ficheiro, !cbSobrescribir.isChecked()));
                        osw.write(etTexto.getText() + "\n");
                        osw.close();
                    } catch (Exception ex) {
                        Toast.makeText(getApplicationContext(), "Error writing the file "+ficheiro, Toast.LENGTH_SHORT).show();
                        Log.e("INTERNA", "Error writing the file "+ficheiro);
                    }
                }else {
                    Toast.makeText(getApplicationContext(), "You can't write in Raw memory", Toast.LENGTH_SHORT).show();
                }
            break;
            case R.id.bRead:
                tv.setText("");
                if (!isRaw) {
                    String linha = "";
                    TextView tv = (TextView) findViewById(R.id.tvShow);
                    try {
                        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(ficheiro)));
                        while ((linha = br.readLine()) != null)
                            tv.append(linha + "\n");
                        br.close();
                    } catch (Exception ex) {
                        Toast.makeText(this, "Error reading the file: "+ficheiro, Toast.LENGTH_SHORT).show();
                        Log.e("SD", "Error reading the file "+ficheiro);
                    }
                }else{
                    if (fiche.equals(""))
                        fiche=edtDirec.getText().toString();
                   Field[] fields = R.raw.class.getFields();
                    for (Field fielss : fields){
                       if(fielss.getName().equals(fiche)){
                           try {
                               InputStream is = getResources().openRawResource(fielss.getInt(fielss));
                               BufferedReader br = new BufferedReader(new InputStreamReader(is));
                               String verso="";
                               while ((verso = br.readLine()) != null)
                                   tv.append(verso + "\n");
                               br.close();
                               is.close();
                           } catch (Exception ex) {

                           }
                           return;

                           }
                       }
                    Toast.makeText(this, "Error reading the file: "+fiche, Toast.LENGTH_SHORT).show();
                    Log.e("SD", "Error reading the file "+fiche);
                }
                break;
            case R.id.bDelete:
                if (!isRaw) {
                    if (ficheiro.delete())
                        Toast.makeText(getApplicationContext(),ficheiro+" has been deleted", Toast.LENGTH_SHORT).show();
                    else {
                        Log.e("INTERNA", "There are problems delering "+ficheiro+" Maybe is not an empty dir");
                        Toast.makeText(this, "There are problems delering "+ficheiro+" Maybe is not an empty dir", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(getApplicationContext(),"You can't delete in Raw memory", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.bList:
                tv.setText("");
                if (!isRaw) {
                    tv.setText(rutaCarpeta + "\n");
                    tv.append("content: " + "\n");
                    if (rutaCarpeta.listFiles() != null) {
                        for (File fille : rutaCarpeta.listFiles()) {
                            String direcOrFile;
                            if (fille.isDirectory())
                                direcOrFile = "Subdirectory: ";
                            else
                                direcOrFile = "File: ";
                            tv.append(direcOrFile + fille.getName() + "\n");
                        }
                    }else
                        Toast.makeText(getApplicationContext(),"Error listing file: "+rutaCarpeta.toString(), Toast.LENGTH_SHORT).show();
                }else{
                    tv.setText("RAW Content:"+"\n");
                   Field[] fields = R.raw.class.getFields();
                    for (Field fielss : fields){
                        tv.append("File: "+fielss.getName()+"\n");
                    }
                }
                break;
        }
    }
}
