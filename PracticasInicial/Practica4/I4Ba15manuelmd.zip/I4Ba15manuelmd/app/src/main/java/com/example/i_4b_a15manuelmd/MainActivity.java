package com.example.i_4b_a15manuelmd;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class MainActivity extends FragmentActivity {
    static ArrayList<String> elementCadro=new ArrayList<String>();
    static ArrayList<Boolean> seleccionados=new ArrayList<Boolean>();
    static ArrayAdapter<String> adapterElement;
    static ListAdapter listAdapt;
    static String nomeFicheiro = "ficheiro_interno.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        adapterElement=new ArrayAdapter<String>(getApplicationContext(), android.R.layout.select_dialog_multichoice ,elementCadro);
        listAdapt=adapterElement;
        TextView tev=findViewById(R.id.texVselec);
        //creo o ficheiro onde se gardan os datos, para que non de erro cando o intenta abrir ao ser a primeira vez que se instalou a app
        crearFicheiro();
       if (elementCadro.isEmpty())
         recuperarDatos();
       actualizarTextView(tev);
    }
    @Override
    protected void onStop() {
        super.onStop();
        escribirEngadir();
    }
    public void crearFicheiro(){
        try {
            OutputStreamWriter osw = new OutputStreamWriter(openFileOutput(nomeFicheiro, Context.MODE_APPEND));
            BufferedReader br = new BufferedReader(new InputStreamReader(openFileInput(nomeFicheiro)));
            if(br.readLine() == null){
                boolean tf=false;
                for (int i=0;i<5;i++) {
                    if (i % 2 == 0)
                        tf = true;
                    else
                        tf = false;
                    osw.write("valorDefault" + i + ":" + tf+"\n");
                }
            }
            br.close();
            osw.close();
        }catch (Exception e){}
    }
    public void escribirEngadir() {
            try {
                OutputStreamWriter osw = new OutputStreamWriter(openFileOutput(nomeFicheiro, Context.MODE_PRIVATE));
                int i=0;
                String cadea="";
                for(String n : elementCadro){
                    cadea=n+":"+seleccionados.get(i);
                    osw.write(cadea + "\n");
                    i++;
                }
                osw.close();
            } catch (Exception ex) {
                Log.e("INTERNA", "Error escribindo no ficheiro");
            }
        }
        public void recuperarDatos() {
            try {
                String linha = "";
                BufferedReader br = new BufferedReader(new InputStreamReader(openFileInput(nomeFicheiro)));
                TextView tv=findViewById(R.id.texVselec);
                tv.setText("");
                while ((linha = br.readLine()) != null){
                    String[] datosExtraidos=linha.split(":");
                    elementCadro.add(datosExtraidos[0]);
                    if (datosExtraidos[1].equals("true")) {
                        seleccionados.add(true);
                    }else
                        seleccionados.add(false);
                }
                br.close();
            } catch (Exception ex) {
                Toast.makeText(this, "Problemas lendo o ficheiro", Toast.LENGTH_SHORT).show();
                Log.e("INTERNA", "Erro lendo o ficheiro. ");
            }
    }
    public void onClicBtnShDial(View v){
    crearDialogo();
    }
    public void onBtnFragment(View v){
        DialogoFramgent dialogo=new DialogoFramgent();
        FragmentManager fm=getSupportFragmentManager();
        dialogo.setTv((TextView)findViewById(R.id.texVselec));
        dialogo.show(fm,"dialogoFragment");
    }

     public void crearDialogo() {
           final ArrayList<Boolean> arLBTemp=new ArrayList<Boolean>();
           final AlertDialog venta = new AlertDialog.Builder(this).setAdapter(listAdapt,null).setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
             @Override
             public void onClick(DialogInterface dialog, int which) {
                    seleccionados=arLBTemp;
                 actualizarTextView((TextView) findViewById(R.id.texVselec));
             }
         }).setNegativeButton("Cancelar", null).setTitle("Show Dialog").create();
            venta.getListView().setBackgroundColor(Color.GRAY);
            venta.getListView().setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
            venta.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialog) {
                    //Restaurase os elementos marcados no array
                    //Crerase un array que conten os cambios dos elementos seleccionados de forma temporal
                    int i=0;
                    for (boolean b : seleccionados) {
                        venta.getListView().setItemChecked(i,b);
                        arLBTemp.add(i,b);
                        i++;
                    }
                }
            });
         venta.getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                 // xestiona os elementos seleccionados
                 CheckedTextView textView = (CheckedTextView) view;
                 if(textView.isChecked()) {
                     arLBTemp.set(position,true);
                 } else {
                     arLBTemp.set(position,false);
                 }
             }
         });
        venta.show();
      }
      public static void actualizarTextView(TextView tvSelec){
            tvSelec.setText("");
            int i=0;
            String gardados="";
            for (boolean b : seleccionados){
                if(b)
                   gardados=gardados+(elementCadro.get(i)+"\n");
                i++;
            }
            tvSelec.setText(gardados);
      }
      public void onClickBtnEngadirElem(View v){
          EditText edt=findViewById(R.id.edTextEng);
          if(!edt.getText().toString().isEmpty()){
             String cadea=String.valueOf(edt.getText());
             elementCadro.add(cadea);
              seleccionados.add(false);
          }
          edt.setText("");
      }
}


