package com.example.i_4b_a15manuelmd;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import java.util.ArrayList;

public class DialogoFramgent extends DialogFragment {
    TextView tv=null;
    @Override
    public Dialog onCreateDialog(final Bundle savedInstanceState) {
        final ArrayList<Boolean> arLBTemp = new ArrayList<Boolean>();
        final AlertDialog venta = new AlertDialog.Builder(getContext()).setAdapter(MainActivity.listAdapt, null)
                .setTitle("Dialog Fragment").setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MainActivity.seleccionados = arLBTemp;
                        MainActivity.actualizarTextView(tv);
                    }
                }).setNegativeButton("Cancelar", null).create();
        venta.getListView().setBackgroundColor(Color.GRAY);
        venta.getListView().setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        venta.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                //Restaurase os elementos marcados no array
                //Crerase un array que conten os cambios dos elementos seleccionados de forma temporal
                int i = 0;
                for (boolean b : MainActivity.seleccionados) {
                    venta.getListView().setItemChecked(i, b);
                    arLBTemp.add(i, b);
                    i++;
                }
            }
        });
        venta.getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // xestiona os elementos seleccionados
                CheckedTextView textView = (CheckedTextView) view;
                if (textView.isChecked()) {
                    arLBTemp.set(position, true);
                } else {
                    arLBTemp.set(position, false);
                }
            }
        });
        return venta;
    }
    //Setter
    public void setTv(TextView tv){
        this.tv=tv;
    }
}


