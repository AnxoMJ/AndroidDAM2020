package com.example.tarefa_i_4_a15manuelmd;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.DialogFragment;

public class Dialogo extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Escolle unha opción");
        builder.setItems(R.array.opcions, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int opcion) {
                if (opcion==0){
                    Intent intent =new Intent(getContext(),ConListView.class);
                    startActivity(intent);
                }else{
                    Intent intent =new Intent(getContext(),ConSpinner.class);
                    startActivity(intent);}
            }
        });
        return builder.create();
    }
}
