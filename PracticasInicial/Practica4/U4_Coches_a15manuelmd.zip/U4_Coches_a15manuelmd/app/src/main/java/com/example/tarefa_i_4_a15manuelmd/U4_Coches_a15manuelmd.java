package com.example.tarefa_i_4_a15manuelmd;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Calendar;

public class U4_Coches_a15manuelmd extends FragmentActivity {
    boolean sdDisponhible = false;
    boolean sdAccesoEscritura = false;
    File dirFicheiroSD;
    File rutaCompleta;
    Dialogo dialogo=new Dialogo();
    static ArrayList<String> listaGardada;
    static String nomeFicheiro = "ficheiroCoches_SD.txt";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        comprobarEstadoSD();
    }
    public void engSobres(View v){
        RadioButton rbEng = findViewById(R.id.rbEngadir);
        EditText edtMarcas= findViewById(R.id.edtMarcas);
        if (sdAccesoEscritura) {
            try {
                String marcaModelo=String.valueOf(edtMarcas.getText());
                String paraGardar=edtMarcas.getText()+"-"+sacarFecha();
                if (!marcaModelo.equals("")) {
                    OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(rutaCompleta, rbEng.isChecked()));
                    osw.write(paraGardar + "\n");
                    Log.i("SD", "Rutaficheiro: " + rutaCompleta.getAbsolutePath());
                    Log.d("SD", "Gardouse: " + paraGardar);
                    osw.close();
                }
            } catch (Exception ex) {
                Log.e("SD", "Error escribindo no ficheiro");
            }
        } else{
            Toast.makeText(this, "A tarxeta SD non está en modo acceso escritura", Toast.LENGTH_LONG).show();
            finish();
        }
        edtMarcas.setText("");
    }

    public void leerGardado() {
        String linha;
        ArrayList<String> lGardados=new ArrayList<String>();
        if (sdDisponhible) {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(rutaCompleta)));

            while ((linha = br.readLine()) != null)
                lGardados.add(linha);
            br.close();
        } catch (Exception ex) {
            Log.e("SD", "Erro lendo o ficheiro. ");
        }
        listaGardada=lGardados;
    }
    }
    public void dialogActivity(View v){
        leerGardado();
        FragmentManager fm = getSupportFragmentManager();
        dialogo.show(fm,"dialogo_duas_opcions");
    }
    public String sacarFecha(){
        Calendar rightNow = Calendar.getInstance();
        String dia=String.valueOf(rightNow.get(Calendar.MONTH));
        String mes=String.valueOf(rightNow.get(Calendar.DAY_OF_MONTH));
        String ano=String.valueOf(rightNow.get(Calendar.YEAR));
        String hor=String.valueOf(rightNow.get(Calendar.HOUR));
        String min=String.valueOf(rightNow.get(Calendar.MINUTE));
        return (dia+"/"+mes+"/"+ano+"_"+hor+":"+min);
    }
    public void comprobarEstadoSD() {
        File[] storages = ContextCompat.getExternalFilesDirs(getApplicationContext(), null);
        if (storages.length > 1 && storages[0] != null && storages[1] != null){
            sdDisponhible = true;
            dirFicheiroSD = storages[1];
            if (dirFicheiroSD.canWrite());
            sdAccesoEscritura=true;
            rutaCompleta = new File(dirFicheiroSD.getAbsolutePath(), nomeFicheiro);
        }
        String estado = Environment.getExternalStorageState();
        Log.e("SD", estado);
    }
}