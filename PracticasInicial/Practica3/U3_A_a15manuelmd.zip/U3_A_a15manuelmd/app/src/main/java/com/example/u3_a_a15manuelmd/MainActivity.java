package com.example.u3_a_a15manuelmd;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final int COD_PETICION = 33;
    Bundle datos=new Bundle();
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button boton = (Button) findViewById(R.id.btnDTB);
        boton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
               AlertDialog dialogo = new AlertDialog.Builder(MainActivity.this).create();
               dialogo.setTitle("Escolle");
               dialogo.setMessage("Ca primeira opción chamas ao número gardado e coa segunda buscas o nome gardado en google");
               dialogo.setButton(Dialog.BUTTON_NEGATIVE, "chamar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (datos.getString("telefono") == null || datos.getString("telefono").equals("")) {
                            Context context = getApplicationContext();
                            Toast.makeText(context, "Tes que poñer un número primeiro", Toast.LENGTH_SHORT).show();
                        } else {
                            //xestiona os permisos e fai a chamada
                            if (Build.VERSION.SDK_INT>=23){
                            int permiso = checkSelfPermission(Manifest.permission.CALL_PHONE);
                            if (permiso ==PackageManager.PERMISSION_GRANTED){
                                chamar(datos.getString("telefono"));
                            }
                            else
                                MainActivity.this.requestPermissions( new String[]{Manifest.permission.CALL_PHONE},COD_PETICION);
                        }else
                                chamar(datos.getString("telefono"));
                        }
                    }
                });
                dialogo.setButton(Dialog.BUTTON_POSITIVE, "Buscar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String busqueda="casa";
                        if (datos.getString("nomeBusqueda")!=null)
                            busqueda=datos.getString("nomeBusqueda");
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q="+busqueda));
                        startActivity(intent);
                    }
                });
                dialogo.show();
                return true;
            }
        });
    }

    public void chamar(String telefono){
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + telefono));
        startActivity(intent);
    }
    public void actBtnDTB(View v) {
        Intent intent = new Intent(this, Main2Activity.class);
        startActivityForResult(intent, COD_PETICION);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == COD_PETICION) {
            if (resultCode == RESULT_OK) {
                datos.putString("nomeBusqueda",data.getStringExtra("NOME"));
                datos.putString("telefono",data.getStringExtra("TELEFONO"));
            }
        } else
            Toast.makeText(this, "Saíches da actividade secundaria sen premer o botón Pechar", Toast.LENGTH_SHORT).show();
    }

    public void actBtnDatos(View v) {
        String mensaxe="";
        if (datos.getString("nomeBusqueda")!=null)
            mensaxe=mensaxe+datos.getString("nomeBusqueda")+" : ";
        if (datos.getString("telefono")!=null)
            mensaxe=mensaxe+datos.getString("telefono");
        if(!mensaxe.equals(""))
            Toast.makeText(getApplicationContext(), mensaxe, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case COD_PETICION: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    chamar(datos.getString("telefono"));
                } else
                    Toast.makeText(this,"É NECESARIO O PERMISO PARA CHAMAR POR TELÉFONO",Toast.LENGTH_LONG).show();
            }
        }
    }
    @Override
    protected void onSaveInstanceState(Bundle estado) {
        estado.putString("nomeBusqueda",datos.getString("nomeBusqueda"));
        estado.putString("telefono",datos.getString("telefono"));
        super.onSaveInstanceState(estado);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        datos=savedInstanceState;
    }
}