package com.example.u3_a_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
    public void actBtnPechar(View v){
        EditText et_nome = (EditText) findViewById(R.id.editTxtNome);
        EditText et_telefono=(EditText) findViewById(R.id.editTxtTlfn);
        String   tlf=et_telefono.getText().toString();
        String  nome=et_nome.getText().toString();
        Intent datos_volta = new Intent();
        datos_volta.putExtra("NOME", nome);
        datos_volta.putExtra("TELEFONO", tlf);
        setResult(RESULT_OK, datos_volta);
        finish();
    }
}
