package com.example.u3_b_a15manuelmd;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class DialogosFragment extends DialogFragment {
    Bundle datos=new Bundle();
    static boolean[]seleccionados= new boolean[] { false, true, false, true, false, false, false };
    static   boolean[] ultSelec;
    static int itemElexido=0;
    static int opcElexida=0;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog result=null;
        AlertDialog.Builder builder= new AlertDialog.Builder(getActivity());
        switch (getTag()) {
            case "btn_dialogo":
                    builder.setTitle("Caixa de diálogo").setIcon(R.mipmap.ic_launcher)
                    .setMessage("QUE TE PARACE ESTE DIALOGO ?");
             result=builder.create();
            break;
            case "btn_diag_tres_botons":
                builder.setTitle("Enquisa")
                        .setIcon(R.mipmap.ic_launcher)
                        .setMessage("Compras sempre en grandes superficies?")
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(getActivity(), "Premeches 'Si", Toast.LENGTH_LONG).show();
                            }
                        }).setNegativeButton("Non", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(getActivity(), "Premeches'Non", Toast.LENGTH_LONG).show();
                            }
                        }).setNeutralButton("Ás veces", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int boton) {
                    Toast.makeText(getActivity(), "Premeches 'Ás veces'", Toast.LENGTH_LONG).show();
                }
            });
                result=builder.create();
                break;
            case "btn_diag_list_selecc":
                builder.setIcon(R.mipmap.ic_launcher)
                        .setTitle("Escolle unha opción")
                        .setItems(R.array.elementos_dialog_seleccion, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int opcion) {
                    String[] opcions = getResources().getStringArray(R.array.elementos_dialog_seleccion);
                    Toast.makeText(getActivity(), "Seleccionaches: '" + opcions[opcion] + "'", Toast.LENGTH_LONG).show();
                }
            });
                result=builder.create();
                break;
            case "btn_diag_radio_button":
                final int selecionadoD4 = itemElexido;
                final CharSequence[] smartphones = { "iPhone", "Blackberry", "Android" };
                builder.setIcon(android.R.drawable.ic_dialog_info)
                .setTitle("Selecciona un smartpohone")
                .setSingleChoiceItems(smartphones, selecionadoD4, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int opcion) {
                        Toast.makeText(getActivity(), "Seleccionaches: " + smartphones[opcion], Toast.LENGTH_SHORT).show();
                        opcElexida =opcion;
                    }
                })
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int boton) {
                        Toast.makeText(getActivity(), "Premeches 'Aceptar' e seleccionaches: "+smartphones[opcElexida], Toast.LENGTH_LONG).show();
                        itemElexido=opcElexida;
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int boton) {
                        Toast.makeText(getActivity(), "Premeches 'Cancelar'", Toast.LENGTH_LONG).show();
                    }
                });
                result=builder.create();
                break;
            case "btn_diag_checkbox":
                Resources res = getResources();
                    //tenho que pasar valor a valo, porque se paso o obxeto, usa a sua referencia e polotanto sempre se gardarian os cambios.
                    boolean[] recuperado=new boolean[7];
                    for (int i=0;i<seleccionados.length;i++){
                        recuperado[i]=(seleccionados[i]);
                    }
                    ultSelec =recuperado;
                final String[] matriz = res.getStringArray(R.array.elementos_dialog_seleccion2);
                builder.setIcon(android.R.drawable.ic_dialog_info)
                .setTitle("Selecciona modos de transporte")
                .setMultiChoiceItems(matriz,ultSelec, new DialogInterface.OnMultiChoiceClickListener() {
                    public void onClick(DialogInterface dialog, int opcion, boolean isChecked) {
                        if (isChecked)
                            Toast.makeText(getActivity(), "Seleccionaches " + matriz[opcion], Toast.LENGTH_SHORT).show();
                        else
                            Toast.makeText(getActivity(), "Deseleccionaches " + matriz[opcion], Toast.LENGTH_SHORT).show();
                    }
                })
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int boton) {
                        String cousasSelec="";
                        int i=0;
                        for (boolean b : ultSelec){
                            if(b)
                                cousasSelec=cousasSelec+matriz[i]+", ";
                            i++;
                        }
                        Toast.makeText(getActivity(), "Premches 'Aceptar'"+" e seleccionaches: "+cousasSelec,  Toast.LENGTH_SHORT).show();
                        Intent intent=getActivity().getIntent();
                        seleccionados=ultSelec;
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int boton) {
                        Toast.makeText(getActivity(), "Premeches 'Cancelar'",  Toast.LENGTH_SHORT).show();
                    }
                });
                result=builder.create();
                break;
            case "btn_diag_entrada_texto":
                String infService = Context.LAYOUT_INFLATER_SERVICE;
                LayoutInflater li = (LayoutInflater) getContext().getSystemService(infService);
                View inflador = li.inflate(R.layout.dialogo_entrada_texto, null);
                final TextView etNome = (TextView) inflador.findViewById(R.id.et_nome);
                final TextView etContrasinal = (TextView) inflador.findViewById(R.id.et_contrasinal);
                builder.setTitle("Indica usuario e contrasinal")
                .setView(inflador)
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int boton) {
                        Toast.makeText(getActivity(), "Escribiches nome: '" + etNome.getText().toString() + "'. Contrasinal: '" + etContrasinal.getText().toString() + "' e premeches 'Aceptar'",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int boton) {
                        Toast.makeText(getActivity(), "Premeches en 'Cancelar'", Toast.LENGTH_SHORT).show();
                    }
                });
                result=builder.create();
                break;
        }
            return result;
    }
}
