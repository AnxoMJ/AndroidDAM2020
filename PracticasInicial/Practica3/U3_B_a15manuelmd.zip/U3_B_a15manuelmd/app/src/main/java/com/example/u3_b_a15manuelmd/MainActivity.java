package com.example.u3_b_a15manuelmd;

import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends FragmentActivity {
    private  DialogosFragment dialogo=new DialogosFragment();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onBotonClick(View view) {
        FragmentManager fm = getSupportFragmentManager();
        switch (view.getId()) {
            case R.id.btn_dialogo:
                dialogo.show(fm,"btn_dialogo");
                break;

            case R.id.btn_diag_tres_botons:
                dialogo.show(fm,"btn_diag_tres_botons");
                break;

            case R.id.btn_diag_list_selecc:
                dialogo.show(fm,"btn_diag_list_selecc");
                break;

            case R.id.btn_diag_radio_button:
                dialogo.show(fm,"btn_diag_radio_button");
                break;

            case R.id.btn_diag_checkbox:
                dialogo.show(fm,"btn_diag_checkbox");
                break;

            case R.id.btn_diag_entrada_texto:
                dialogo.show(fm,"btn_diag_entrada_texto");
                break;
            default:
                break;
        }
    }
}