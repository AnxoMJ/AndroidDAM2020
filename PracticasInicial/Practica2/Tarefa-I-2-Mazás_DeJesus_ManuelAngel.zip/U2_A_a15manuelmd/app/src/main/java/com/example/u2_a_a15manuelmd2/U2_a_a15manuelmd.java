package com.example.u2_a_a15manuelmd2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.Chronometer;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class U2_a_a15manuelmd extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.ic_launcher_round);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        Switch switchCrono = (Switch) findViewById(R.id.switchCrono);
        Spinner spinPlanetas = (Spinner) findViewById(R.id.spinner);
        //Listeners----------------------------------------------------------------------------------
        spinPlanetas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            Context context = getApplicationContext();
            int duration = Toast.LENGTH_SHORT;
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                // TODO Auto-generated method stub
                int cont=0;
                for(String p : getResources().getStringArray(R.array.placesGalicia)){
                    String p1=(String.valueOf(parent.getItemAtPosition(pos)));
                    if(p.equals(p1))
                        cont++;
                }
                CharSequence msgtoast = getString(R.string.text_toast_no_gal);
                if(cont==1)
                    msgtoast = getString(R.string.text_toast_gal);
                Toast.makeText(context, msgtoast, duration).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        switchCrono.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Chronometer crono = findViewById(R.id.crono);
                crono.setBase(SystemClock.elapsedRealtime());
                if(isChecked)
                    crono.start();
                else
                    crono.stop();
            }
        });
        final Chronometer cronoLs= (Chronometer) findViewById(R.id.crono);
        cronoLs.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                if(String.valueOf(chronometer.getText()).equals("00:15"))
                    finish();
                }
        });
    }
    public void rbColors(View v) {
        RadioButton rbt= (RadioButton)v;
        TextView textview= findViewById(R.id.textview1);
        if((rbt.getId())==R.id.rbtn_red)
            textview.setTextColor(getColor(R.color.colorRed));
        else
            textview.setTextColor(getColor(R.color.colorBlue));
    }
    public void btnAddClear(View v) {
        CheckBox cb =findViewById(R.id.cbClear);
        EditText textIn =findViewById(R.id.edtext);
        TextView textview= findViewById(R.id.textview1);
        if(cb.isChecked())
            textview.setText("");
        else
            textview.append(" "+textIn.getText());
        textIn.setText("");
    }
    public void descImg(View v) {
        Context context = getApplicationContext();
        CharSequence text = getResources().getString(R.string.text_image);
        int duration = Toast.LENGTH_SHORT;
        Toast.makeText(context, text, duration).show();
    }
}
