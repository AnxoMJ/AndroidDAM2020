package com.example.ud_a3a_thread_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int vObxetivo=30;
    int vCrono=0;
    boolean pararFio=true;
    boolean pararATask=true;
    CronoAsyncTask cronoAsyncTask;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView mdb=findViewById(R.id.marcDebug);
    }
    public void onClickStartThread(View v){
        if(!pararATask){
            Toast.makeText(this,"EMPEZAR(AsynnkTask) esta funcionando,parao para usar este método!!!",Toast.LENGTH_SHORT).show();
            return;
        }
        if(!pararFio){
            Toast.makeText(this,"EMPEZAR(Fio) esta funcionando,parao para usar este método!!!",Toast.LENGTH_SHORT).show();
            return;
        }
        pararFio=false;
        vCrono=20;
        fioCrono();
        setMarcador();
    }
    public void onClickStartAsynkTask(View v){
        if(!pararFio){
            Toast.makeText(this,"EMPEZAR(Thread) esta funcionando,parao para usar este método!!!",Toast.LENGTH_SHORT).show();
            return;
        }
        if(!pararATask){
            Toast.makeText(this,"EMPEZAR(AsynnkTask) esta funcionando,parao para usar este método!!!",Toast.LENGTH_SHORT).show();
            return;
        }
        pararATask=false;
        setMarcador();
        cronoAsyncTask = new CronoAsyncTask();
        cronoAsyncTask.execute();
    }

    public void onClickStopThread(View v){
        if(pararFio){
        Toast.makeText(this,"O fio esta parado",Toast.LENGTH_SHORT).show();
        return;
        }
        pararFio=true;
        ganado();
    }
    public void onClickStopAsynkTask(View v){
        if(pararATask){
            Toast.makeText(this,"O fio esta parado",Toast.LENGTH_SHORT).show();
            return;
        }
        ganado();
        if ((cronoAsyncTask!=null) ){
            cronoAsyncTask.cancel(true);
            pararATask=true;
        }
    }
    public void setMarcador(){
        TextView marcador=findViewById(R.id.marcador);
        vObxetivo=(int)((Math.random()*6)+5);
       marcador.setText(String.valueOf(vObxetivo));
    }
    public void ganado(){
        if(vObxetivo==vCrono) {
            Toast.makeText(this, "Ganaches!!!" + " valorCrono: " + vCrono + " valorObxetivo: " + vObxetivo, Toast.LENGTH_LONG).show();
        }else if (vCrono==0){
            Toast.makeText(this,"Acabou o tempo",Toast.LENGTH_LONG).show();
            pararFio=true;
            pararATask=true;
        }else{
            Toast.makeText(this,"valorCrono: "+vCrono,Toast.LENGTH_LONG).show();
            vCrono=0;}
    }
    public void showToast(final String toast)
    {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, toast, Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void fioCrono(){

        Thread fio = new Thread(){
            public void run(){
                for (int a=20;a>=0;a--){
                    try {
                        if(pararFio)
                            return;
                        vCrono=a;
                        Thread.sleep(1000);
                        Log.i("THREAD",String.valueOf(a));
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                showToast("Terminou o tempo");
                pararFio=true;
            } 	// FIN DO RUN
        };
        fio.start();
    }

    private class CronoAsyncTask extends AsyncTask<Void, Integer, Boolean> {

        @Override
        protected Boolean doInBackground(Void... params) {
            for (int a=20;a>=0;a--) {
                if (isCancelled())
                    break;
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                publishProgress(a);
                Log.i("THREAD ",String.valueOf(a));
                if (a==0){
                    showToast("Terminou o tempo");
                    pararATask=true;
                }
            }
            return true;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            vCrono=values[0];
            super.onProgressUpdate(values);
        }
    };
}
