package com.example.ud_a2a_a15manuelmd;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;

import static android.os.Environment.getExternalStorageDirectory;

public class MainActivity extends AppCompatActivity {

    private static final int CODIGO_IDENTIFICADOR =1 ;
    private static final int REQUEST_CODE_GRAVACION_OK = 13;
    private static final int REQUEST_CODE_CAMARA = 12;
    boolean sdDisponhible = false;
    boolean sdAccesoEscritura = false;
    //final String RMUSIC="/sdcard/UD-A2A/MUSICA/";
    //final String RFOT="/sdcard/UD-A2A/FOTO/";
     String RMUSIC;
     String RFOT;
    private MediaPlayer mediaplayer;
    final private String nomeFoto="foto.jpeg";
    private boolean pause;
    private MediaRecorder mediaRecorder;
    private String arquivoGravar;
    static int contPerm=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        RMUSIC=getExternalFilesDir(null).getAbsolutePath()+"/UD-A2A/MUSICA/";
        RFOT=getExternalFilesDir(null).getAbsolutePath()+"/UD-A2A/FOTO/";
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        comprobarEstadoSD();
        try {
            if (sdAccesoEscritura)
            xestionarEventos();
            else{
                Toast.makeText(this,"A sd non esta en modo escritura ou non esta montada".toString(),Toast.LENGTH_LONG).show();
            finish();}
        }catch (Exception e){
            Toast.makeText(this,"Error Copiando Os audios".toString(),Toast.LENGTH_LONG).show();
        }
        //cargarFoto();
        mediaplayer = new MediaPlayer();
    }

    public void onClickGravar(View v)  {
        mediaplayer.stop();
        mediaplayer.reset();
        String timeStamp = DateFormat.getDateTimeInstance().format(
                new Date()).replaceAll(":", "").replaceAll("/", "_")
                .replaceAll(" ", "_");
        mediaRecorder = new MediaRecorder();
       // arquivoGravar = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) + timeStamp + ".3gp";
        arquivoGravar = RMUSIC + "record.3gp";
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setMaxDuration(10000);
        mediaRecorder.setAudioEncodingBitRate(32768);
        mediaRecorder.setAudioSamplingRate(8000); // No emulador só 8000 coma
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mediaRecorder.setOutputFile(arquivoGravar);
        try {
            mediaRecorder.prepare();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            mediaRecorder.reset();
        }
        try {
            mediaRecorder.start();
        }catch (Exception e){};

        abrirDialogo("GRAVAR");
        try {
            cargarMusica();
        }catch (Exception e){
            Toast.makeText(this,"Error cargando música".toString(),Toast.LENGTH_LONG).show();
        }

    }

    public void onClickFoto(View v)  {
        ///
        ///uri fai que crashe a app
        ///
      /*  File ruta = new File(RFOT);
        File arquivo = new File(ruta,nomeFoto);
        Intent intento = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        Uri t=Uri.fromFile(arquivo);
        intento.putExtra(MediaStore.EXTRA_OUTPUT, t);
        // intento.putExtra(MediaStore.EXTRA_OUTPUT,arquivo);

       // Uri t=Uri.parse();
        //Toast.makeText(this,t.toString(),Toast.LENGTH_LONG).show();
        */

        Intent intento = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intento, REQUEST_CODE_GRAVACION_OK);
    }
    private void abrirDialogo(String tipo){

        if (tipo == "GRAVAR") {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                    .setMessage("GRAVANDO").setPositiveButton(
                            "PREME PARA PARAR",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    // TODO Auto-generated method stub
                                    //mediaRecorder.stop();
                                    try {
                                        mediaRecorder.stop();
                                    }catch (Exception e){};
                                    mediaRecorder.release();
                                    mediaRecorder = null;

                                }
                            });
            dialog.show();
        }
    }
    public void comprobarEstadoSD() {
        String estado = Environment.getExternalStorageState();
        Log.e("SD", estado);

        if (estado.equals(Environment.MEDIA_MOUNTED)) {
            sdDisponhible = true;
            sdAccesoEscritura = true;
        } else if (estado.equals(Environment.MEDIA_MOUNTED_READ_ONLY))
            sdDisponhible = true;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==13){
            if (resultCode == RESULT_OK) {
                if (data == null) {
                    return;
                }
                try {
                    File ruta = new File(RFOT);
                    File arquivo = new File(ruta,nomeFoto);
                    if (arquivo.exists())
                        arquivo.delete();
                    FileOutputStream fo =new FileOutputStream(arquivo.getAbsolutePath(),true);
                    Bitmap img=(Bitmap) data.getExtras().get("data");
                    img.compress(Bitmap.CompressFormat.JPEG,100,fo);
                    cargarFoto();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void onClickReproducir(View v)  {
        Spinner spMusica=findViewById(R.id.spMusica);
        if (spMusica.getCount()==0){
            Toast.makeText(this,"Non se seleccionou nada",Toast.LENGTH_LONG).show();
        return;
        }
       File fMusica = new File(RMUSIC+spMusica.getSelectedItem().toString());
        Uri uri = Uri.parse(fMusica.getAbsolutePath());
        try {
            mediaplayer.reset();
            mediaplayer.setDataSource(getApplicationContext(),uri);
            mediaplayer.prepare();
            mediaplayer.start();
        }catch (Exception e){
            String s=e.getMessage().toString();
            Toast.makeText(this,fMusica.getAbsolutePath(),Toast.LENGTH_LONG).show();
        }
    }

    public void cargarFoto()  {
        File ruta = new File(RFOT);
        for (File f:ruta.listFiles()){
            if(f.getName().contains(".jpeg")){
                Bitmap myBitmap = BitmapFactory.decodeFile(f.getAbsolutePath());
                ImageView myImage = (ImageView) findViewById(R.id.imgView);
                myImage.setImageBitmap(myBitmap);
                return;
            }
        }
    }

    public void cargarMusica() throws Exception{
        File fMusica = new File(RMUSIC);
        ArrayList<String>arMus=new ArrayList<>();
        for (File archivo: fMusica.listFiles()){
            arMus.add(archivo.getName());
        }
        Spinner spMusica=findViewById(R.id.spMusica);
        ArrayAdapter<String> adapMusic=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arMus);
        spMusica.setAdapter(adapMusic);
    }

    private void pasarArchivos() throws IOException {
        Field[] fields = R.raw.class.getFields();
        for(Field f:fields){

        try {
            InputStream is_raw = getResources().openRawResource(f.getInt(f));
            File fsaida = new File(RMUSIC+f.getName()+".mp3");
            if (fsaida.exists()) continue;
        FileOutputStream fos_sdcard = new FileOutputStream(fsaida);
        int tamRead;
        byte[] buffer = new byte[524288];
        while((tamRead = is_raw.read(buffer))>0){
            fos_sdcard.write(buffer, 0, tamRead);
        }
        fos_sdcard.flush();
        fos_sdcard.close();
        is_raw.close();
        }catch (Exception e){
            Toast.makeText(this,"Problema copiando",Toast.LENGTH_LONG).show();
        }
        }
    }

    public void prepararCarpetas(){
    File  rutaMusic = new File(RMUSIC);
    File  rutaFotos = new File(RFOT);
        rutaMusic.mkdirs();
        rutaFotos.mkdirs();
    }

    private void xestionarEventos() throws Exception{
            if (Build.VERSION.SDK_INT>=23){
                requestPermissions( new String[]{Manifest.permission.RECORD_AUDIO,Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission_group.CAMERA,Manifest.permission_group.STORAGE},CODIGO_IDENTIFICADOR);
            }else{
                prepararCarpetas();
                pasarArchivos();
                cargarMusica();
                cargarFoto();
            }
        }

    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        switch (requestCode) {
            case CODIGO_IDENTIFICADOR: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED && grantResults[2] == PackageManager.PERMISSION_GRANTED) {
                    try{
                    prepararCarpetas();
                    pasarArchivos();
                    cargarMusica();
                    cargarFoto();}
                    catch (Exception e){
                      //  Toast.makeText(this,"Error procesando a musica",Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(this,"Para usar a app tes que conceder todos os permisos",Toast.LENGTH_LONG).show();
                    contPerm++;
                    if (contPerm>=1)
                    finish();
                }
                return;
            }
        }
    }
}