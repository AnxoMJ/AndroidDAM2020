package com.example.ud_a_45_c_a15manueld;

import java.util.ArrayList;
import java.util.List;

public class Salary {
    String month;
    int amount;
    ArrayList<Complements> complements;

    public String getMouth() {
        return month;
    }

    public void setMouth(String mouth) {
        this.month = mouth;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public List<Complements> getComplements() {
        return complements;
    }

    public void setComplements(ArrayList<Complements> complements) {
        this.complements = complements;
    }

    @Override
    public String toString() {
        return "Salary{" +
                "mouth='" + month + '\'' +
                ", amount=" + amount +
                ", complements=" + complements +
                '}';
    }
}
