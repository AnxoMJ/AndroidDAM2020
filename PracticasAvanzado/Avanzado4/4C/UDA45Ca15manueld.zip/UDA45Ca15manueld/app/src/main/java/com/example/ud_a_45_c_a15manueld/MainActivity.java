package com.example.ud_a_45_c_a15manueld;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.xmlpull.v1.XmlPullParser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static String nomeFicheiro = "ficheiro_SD.txt";
    private String DOC_DESCARGAR = "https://manuais.iessanclemente.net/images/5/53/Salaries2.xml";
    private EditText edt;
    private static ArrayList<Salary> arSalary = new ArrayList<Salary>();
    private TIPOREDE conexion;
    private MiñaTarefa miñaTarefa;
    static BaseDeDatos d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt = findViewById(R.id.edtURL);
        edt.setText(DOC_DESCARGAR);
        File db = getDatabasePath(BaseDeDatos.NOME_BD);
        if (!db.exists()) {
            d = new BaseDeDatos(getApplicationContext());
        }
    }

    public void onClickDownload(View v) {
        redeDisponhible();
        EditText edtUrl = findViewById(R.id.edtURL);
        TextView tv = findViewById(R.id.tvTemp);
        tv.setText("");
        DOC_DESCARGAR = edtUrl.getText().toString();
        if (conexion != TIPOREDE.SENREDE) {

            if ((miñaTarefa == null) || (miñaTarefa.getStatus() == AsyncTask.Status.FINISHED)) {
                miñaTarefa = new MiñaTarefa();
                miñaTarefa.execute();
            } else {
                Toast.makeText(getApplicationContext(), "A tarefa non acabou!!!",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void onClickXMLPro(View v) {
        cargarXml();
        gardarNaBD();
    }

    public void onClickShSalaries(View v) {
        mostrarLista();
    }
///////////////base de datos///////////////////////////////////

    public void gardarNaBD() {
        cargarXml();
        if (arSalary.size() == 0) {
            Toast.makeText(this, "Non se descargou ou non existen datos no xml", Toast.LENGTH_LONG).show();
            return;
        }
        for (Salary r : arSalary) {
            int sum = 0;
            for (Complements num : r.complements) {
                sum += num.type;
            }
            sum += r.amount;
            BaseDeDatos db = new BaseDeDatos(getApplicationContext());
            SQLiteDatabase sqlLiteDB = db.getWritableDatabase();
            try {
                Cursor cursor = sqlLiteDB.rawQuery("select month from salary where month = ?", new String[]{r.month});
                if (cursor.moveToFirst()) {
                    Toast.makeText(this, "Mes repetido: " + cursor.getString(0), Toast.LENGTH_SHORT).show();

                } else
                    sqlLiteDB.execSQL("INSERT INTO salary(month,total_salary) values('" + r.month + "','" + sum + "')");
            } catch (Exception e) {
                Toast.makeText(this, "Error na inserción, verifique os datos aportados", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /////////////////////////////////////fin BD////////////////////////////////////////////////////////
    public void cargarXml() {
        String fich = getFilesDir().getAbsolutePath() + "/xmlFile.xml";
        File rutaArquivo = new File(fich);
        if (!rutaArquivo.exists()) {
            Toast.makeText(this, "Non Existe o ficheiro xml", Toast.LENGTH_LONG).show();
            arSalary.clear();
            return;
        }
        try {
            InputStream is = new FileInputStream(fich);
            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(is, "UTF-8");
            int evento = parser.nextTag();
            Salary salary = null;
            List<Complements> complementsL;
            arSalary.clear();
            while (evento != XmlPullParser.END_DOCUMENT) {
                if (evento == XmlPullParser.START_TAG) {
                    if (parser.getName().equals("salary")) {    // Un novo ruta
                        salary = new Salary();
                        evento = parser.nextTag();
                        salary.setMouth(parser.nextText());
                        evento = parser.nextTag();
                        salary.setAmount(Integer.valueOf(parser.nextText()));
                        ArrayList<Complements> arComp = new ArrayList<Complements>();
                        while (evento != XmlPullParser.END_TAG) {
                            evento = parser.nextTag();
                            if (evento == XmlPullParser.END_TAG)
                                break;
                            arComp.add(new Complements(Integer.valueOf(parser.nextText())));
                        }
                        salary.setComplements(arComp);
                    }
                }
                if (evento == XmlPullParser.END_TAG) {
                    if (parser.getName().equals("salary")) {    // Un novo ruta
                        arSalary.add(salary);
                        // Toast.makeText(this, salary.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
                evento = parser.next();
            }
            is.close();
        } catch (Exception e) {
            //Toast.makeText(this, "Excepcion:" + e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.e("ERROR:Parse", e.getMessage());
        }
    }

    public void mostrarLista() {
        TextView tv = findViewById(R.id.tvTemp);
        tv.setText("");
        BaseDeDatos db = new BaseDeDatos(getApplicationContext());
        SQLiteDatabase sqlLiteDB = db.getWritableDatabase();
        Cursor datosConsulta = sqlLiteDB.rawQuery("SELECT * FROM salary", null);
        if (datosConsulta.moveToFirst()) {
            tv.append("Total_Salary    Month." + "\n");
            while (!datosConsulta.isAfterLast()) {
                tv.append("       " + datosConsulta.getInt(1) + "           " + datosConsulta.getString(0) + "\n");
                datosConsulta.moveToNext();
            }
        } else
            Toast.makeText(this, "A base non conten datos", Toast.LENGTH_SHORT).show();
    }

    private boolean descargarArquivo() {
        URL url = null;
        try {
            url = new URL(DOC_DESCARGAR);
        } catch (MalformedURLException e1) {
            e1.printStackTrace();
            return false;
        }
        HttpURLConnection conn = null;
        String nomeArquivo = Uri.parse(DOC_DESCARGAR).getLastPathSegment();
        File rutaArquivo = new File(getFilesDir().getAbsolutePath() + "/xmlFile.xml");
        if (rutaArquivo.exists())
            rutaArquivo.delete();
        try {
            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);    /* milliseconds */
            conn.setConnectTimeout(15000);  /* milliseconds */
            conn.setRequestMethod("POST");
            conn.setDoInput(true);            /* Indicamos que a conexión vai recibir datos */
            conn.connect();

            int response = conn.getResponseCode();
            if (response != HttpURLConnection.HTTP_OK) {
                throw new IllegalArgumentException();
                //return false;
            }
            OutputStream os = new FileOutputStream(rutaArquivo);
            InputStream in = conn.getInputStream();
            byte[] data = new byte[1024];    // Buffer a utilizar
            int count;
            while ((count = in.read(data)) != -1) {
                os.write(data, 0, count);
            }
            os.flush();
            os.close();
            in.close();
            conn.disconnect();
            Log.i("COMUNICACION", "ACABO");
            return true;
        } catch (FileNotFoundException e) {
            Log.e("COMUNICACION", e.getMessage());
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("COMUNICACION", e.getMessage());
            return false;
        }
    }

    private class MiñaTarefa extends AsyncTask<Void, Integer, Boolean> {

        @Override
        protected Boolean doInBackground(Void... params) {
            try {
                return descargarArquivo();
            } catch (Exception e) {
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                Toast.makeText(getApplicationContext(), "Ficheiro descargado",
                        Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(getApplicationContext(), "Ficheiro non descargado!",
                        Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onCancelled() {
            Toast.makeText(getApplicationContext(), "Tarea cancelada!",
                    Toast.LENGTH_SHORT).show();
        }
    }


    ///////Rede///////////////////////////////////////////////////////////////////

    public void redeDisponhible() {
        conexion = comprobarRede();
        if (conexion == TIPOREDE.SENREDE) {
            Toast.makeText(this, "NON SE PODE FACER ESTA PRACTICA SEN CONEXION A INTERNET", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private TIPOREDE comprobarRede() {
        NetworkInfo networkInfo = null;
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            switch (networkInfo.getType()) {
                case ConnectivityManager.TYPE_MOBILE:
                    return TIPOREDE.MOBIL;
                case ConnectivityManager.TYPE_ETHERNET:
                    return TIPOREDE.ETHERNET;
                case ConnectivityManager.TYPE_WIFI:
                    return TIPOREDE.WIFI;
            }
        }
        return TIPOREDE.SENREDE;
    }

    public enum TIPOREDE {MOBIL, ETHERNET, WIFI, SENREDE}
}
