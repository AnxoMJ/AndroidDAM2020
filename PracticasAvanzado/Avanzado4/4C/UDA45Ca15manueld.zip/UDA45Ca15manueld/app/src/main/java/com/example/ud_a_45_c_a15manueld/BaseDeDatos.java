package com.example.ud_a_45_c_a15manueld;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BaseDeDatos extends SQLiteOpenHelper {
    SQLiteDatabase db;
    public final static String NOME_BD="salaries.db";
    public final static int VERSION_BD=1;
    String CREAR_TABOA ="CREATE TABLE salary ( " +
            "month  VARCHAR(10) PRIMARY KEY ," +
            "total_salary REAL(10)  NOT NULL)";
    public BaseDeDatos(Context context) {
        super(context, NOME_BD, null, VERSION_BD);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREAR_TABOA);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}


}