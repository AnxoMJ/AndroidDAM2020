package com.example.ud_a_45_c_a15manueld;

public class Complements {
    int type;

    public Complements(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        type = type;
    }

    @Override
    public String toString() {
        return String.valueOf(type);
    }
}
