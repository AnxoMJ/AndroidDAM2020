package com.example.ud_a_45_a_a15manuelmd;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.xmlpull.v1.XmlPullParser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static String nomeFicheiro = "ficheiro_SD.txt";
    private final String DOC_DESCARGAR = "https://manuais.iessanclemente.net/images/2/20/Platega_pdm_rutas.xml";
    boolean sdDisponhible = false;
    boolean sdAccesoEscritura = false;
    File dirFicheiroSD;
    File rutaCompleta;
    ArrayList<Ruta> arRutas = new ArrayList<Ruta>();
    private TIPOREDE conexion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        comprobarEstadoSD();
        crearDirectorio();
    }

    public void onClickDescargar(View v) {
        redeDisponhible();
        if (conexion != TIPOREDE.SENREDE) {
            Thread thread = new Thread() {

                @Override
                public void run() {
                    descargarArquivo();
                }
            };
            thread.start();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            cargarXml();
        }
    }


    public void cargarXml() {
        File rutaArquivo = new File(dirFicheiroSD.getAbsolutePath() + "/RUTAS/Platega_pdm_rutas.xml");
        if (!rutaArquivo.exists()) {
            Toast.makeText(this, "Non Existe", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            //InputStream is = getAssets().open(dirFicheiroSD.getAbsolutePath() + "/RUTAS/Platega_pdm_rutas.xml");
            InputStream is = new FileInputStream(dirFicheiroSD.getAbsolutePath() + "/RUTAS/Platega_pdm_rutas.xml");
            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(is, "UTF-8");

            int evento = parser.nextTag();
            Ruta ruta = null;
            arRutas.clear();
            while (evento != XmlPullParser.END_DOCUMENT) {
                if (evento == XmlPullParser.START_TAG) {
                    if (parser.getName().equals("ruta")) {    // Un novo ruta
                        ruta = new Ruta();
                        evento = parser.nextTag();    // Pasamos a <nome>
                        ruta.setNome(parser.nextText());
                        evento = parser.nextTag();    // Pasamos a <dir>
                        ruta.setDescripcion(parser.nextText());
                    }
                }
                if (evento == XmlPullParser.END_TAG) {
                    if (parser.getName().equals("ruta")) {    // Un novo ruta
                        arRutas.add(ruta);
                    }
                }
                evento = parser.next();
            }
            is.close();
        } catch (Exception e) {
            Log.e("ERROR:Parse", e.getMessage());
        }
        TextView tv = findViewById(R.id.tevXml);
        tv.setText("");
        for (Ruta r : arRutas) {
            tv.append(r + "\n");
        }
    }

    private void descargarArquivo() {
        URL url = null;
        try {
            url = new URL(DOC_DESCARGAR);
        } catch (MalformedURLException e1) {
            e1.printStackTrace();
            return;
        }

        HttpURLConnection conn = null;
        String nomeArquivo = Uri.parse(DOC_DESCARGAR).getLastPathSegment();
        File rutaArquivo = new File(dirFicheiroSD.getAbsolutePath() + "/RUTAS/" + nomeArquivo);
        try {
            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);    /* milliseconds */
            conn.setConnectTimeout(15000);  /* milliseconds */
            conn.setRequestMethod("POST");
            conn.setDoInput(true);            /* Indicamos que a conexión vai recibir datos */
            conn.connect();

            int response = conn.getResponseCode();
            if (response != HttpURLConnection.HTTP_OK) {
                return;
            }
            OutputStream os = new FileOutputStream(rutaArquivo);
            InputStream in = conn.getInputStream();
            byte[] data = new byte[1024];    // Buffer a utilizar
            int count;
            while ((count = in.read(data)) != -1) {
                os.write(data, 0, count);
            }
            os.flush();
            os.close();
            in.close();
            conn.disconnect();
            Log.i("COMUNICACION", "ACABO");
        } catch (FileNotFoundException e) {
            Log.e("COMUNICACION", e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("COMUNICACION", e.getMessage());
        }

    }

    public void redeDisponhible() {
        conexion = comprobarRede();
        if (conexion == TIPOREDE.SENREDE) {
            Toast.makeText(this, "NON SE PODE FACER ESTA PRACTICA SEN CONEXION A INTERNET", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private TIPOREDE comprobarRede() {
        NetworkInfo networkInfo = null;
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            switch (networkInfo.getType()) {
                case ConnectivityManager.TYPE_MOBILE:
                    return TIPOREDE.MOBIL;
                case ConnectivityManager.TYPE_ETHERNET:
                    return TIPOREDE.ETHERNET;
                case ConnectivityManager.TYPE_WIFI:
                    return TIPOREDE.WIFI;
            }
        }
        return TIPOREDE.SENREDE;
    }

    public void comprobarEstadoSD() {
        String estado = Environment.getExternalStorageState();
        Log.e("SD", estado);
        if (estado.equals(Environment.MEDIA_MOUNTED)) {
            sdDisponhible = true;
            sdAccesoEscritura = true;
        } else if (estado.equals(Environment.MEDIA_MOUNTED_READ_ONLY))
            sdDisponhible = true;
    }

    public void crearDirectorio() {
        if (sdDisponhible) {
            // dirFicheiroSD = Environment.getExternalStorageDirectory();
            dirFicheiroSD = getExternalFilesDir(null);
            rutaCompleta = new File(dirFicheiroSD.getAbsolutePath() + "/RUTAS/");
            rutaCompleta.mkdir();
        }
    }

    public enum TIPOREDE {MOBIL, ETHERNET, WIFI, SENREDE}
}
