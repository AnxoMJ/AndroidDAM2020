package com.example.ud_a_45_a_a15manuelmd;

public class Ruta {
    String nome;
    String descripcion;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return nome + "-" + descripcion;
    }
}
