package com.example.ud_a1a_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MainActivity extends AppCompatActivity {
   static BaseDeDatos d ;
    static boolean bdPorCodigo =false ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        File db = getDatabasePath(BaseDeDatos.NOME_BD);
        if (!db.exists()) {
            primeiraVez();
        }
    }
    public void onBtBD(View v){
        Intent intent = new Intent(this,GardarNaBD.class);
        startActivity(intent);
    }
    public void onBtFich(View v){
        Intent intent = new Intent(this,ActivityGardarAFicheiro.class);
        startActivity(intent);
    }
    public void primeiraVez(){
        Toast.makeText(this,"Esta é a primeira vez",Toast.LENGTH_LONG).show();

        AlertDialog.Builder venta = new AlertDialog.Builder(this);
        venta.setIcon(android.R.drawable.ic_dialog_info);
        venta.setTitle("Aviso");
        venta.setMessage("Como queres xerar a base de datos?");
        venta.setCancelable(false);
        venta.setPositiveButton("Mediante asset", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int boton) {
                copiarBase();
            }
        });
        venta.setNegativeButton("Mediante código", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int boton) {
                crearBasePorCodigo();
            }
        });
        venta.create();
        venta.show();
    }
    public void copiarBase(){
        File db = getDatabasePath(BaseDeDatos.NOME_BD);
        if (!db.exists()) {
            if(!db.getParentFile().exists()){
                db.getParentFile().mkdirs();
            }
            try {
                InputStream is = getAssets().open(BaseDeDatos.NOME_BD);
                OutputStream os = new FileOutputStream(db);
                int tamread;
                byte[] buffer = new byte[2048];

                while ((tamread = is.read(buffer)) > 0) {
                    os.write(buffer, 0, tamread);
                }
                is.close();
                os.flush();
                os.close();
            } catch (IOException e) {
                Log.e("ERROR", e.getMessage());
            }
        }
    }
    public void crearBasePorCodigo(){
       bdPorCodigo=true;
       d =new BaseDeDatos(getApplicationContext());
    }
}
