package com.example.ud_a1a_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentUris;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class ActivityGardarAFicheiro extends AppCompatActivity {
    boolean sdDisponhible = false;
    boolean sdAccesoEscritura = false;
    File dirFicheiroSD;
    File rutaCompleta;
    ArrayList<String>nom;
    ArrayList<String>desc;
    String nomeFicheiro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gardar_aficheiro);
        metCrear();
        SharedPreferences sharedpref = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpref.edit();
        editor.putString("RUTA_PARA_SD","DATOS");
        editor.commit();
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions( new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = new Intent(getApplicationContext(), preferencias.class);
        startActivityForResult(intent,1);
        return true;
    }


    public void metCrear(){
        Spinner spinner = findViewById(R.id.spLisaNomes);
        final TextView tvDesc = findViewById(R.id.tvDescrip);
        nom=new ArrayList<String>();
        desc=new ArrayList<String>();
        BaseDeDatos db = new BaseDeDatos(getApplicationContext());
        SQLiteDatabase sqlLiteDB = db.getWritableDatabase();
        Cursor cursor = sqlLiteDB.rawQuery("select * from PERSOAS", null);
        if (cursor.moveToFirst()) {                // Se non ten datos xa non entra
            while (!cursor.isAfterLast()) {     // Quédase no bucle ata que remata de percorrer o cursor. Fixarse que leva un ! (not) diante
                String nome = cursor.getString(0);
                String descr = cursor.getString(1);
                cursor.moveToNext();
                nom.add(nome);
                desc.add(descr);
            }
        }
        spinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, nom));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                tvDesc.setText(desc.get(position).toString());
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 1) {
            Spinner spinner = findViewById(R.id.spLisaNomes);
            SharedPreferences preferencias = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
             // Toast.makeText(this,preferencias.getString("ruta_para_a_sd","DATOS"),Toast.LENGTH_LONG).show();
            //String nomeFicheiro="";
              try{
                   nomeFicheiro =preferencias.getString("ruta_para_a_sd","DATOS")+"/"+spinner.getSelectedItem().toString()+".txt";}
              catch (Exception E){
                  Toast.makeText(this,"Non se seleccionou nada",Toast.LENGTH_LONG).show();
                  return;
              }

        }
    }
    public void onBtgardarFicheiro(View v){
        comprobarEstadoSD();
        if (!sdDisponhible){
            Toast.makeText(this,"SD non montada",Toast.LENGTH_LONG).show();
            return;
        }

            Spinner spinner = findViewById(R.id.spLisaNomes);
            SharedPreferences preferencias = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            // Toast.makeText(this,preferencias.getString("ruta_para_a_sd","DATOS"),Toast.LENGTH_LONG).show();
        try{
            nomeFicheiro =preferencias.getString("ruta_para_a_sd","DATOS")+"/"+spinner.getSelectedItem().toString()+".txt";}
        catch (Exception E){
            Toast.makeText(this,"Non se seleccionou nada",Toast.LENGTH_LONG).show();
            return;
        }
            rutaCompleta = new File(dirFicheiroSD.getAbsolutePath()+"/"+preferencias.getString("ruta_para_a_sd","DATOS"));
            rutaCompleta.mkdirs();
            rutaCompleta = new File(dirFicheiroSD.getAbsolutePath(), nomeFicheiro);

            if (sdAccesoEscritura) {
                try {
                    int pos=spinner.getSelectedItemPosition();
                    String paraGardar="Nome: "+nom.get(pos)+"\n"+"Descripcion: "+desc.get(pos);
                    OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(rutaCompleta, false));
                    osw.write(paraGardar + "\n");
                    Log.i("SD", "Rutaficheiro: " + rutaCompleta.getAbsolutePath());
                    Log.d("SD", "Gardouse: " + paraGardar);
                    osw.close();
                    Toast.makeText(this, "Archivo gardado", Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Log.e("SD", "Error escribindo no ficheiro");
                    Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else{
                Toast.makeText(this, "A tarxeta SD non está en modo acceso escritura", Toast.LENGTH_LONG).show();
                finish();
            }
    }
    public void comprobarEstadoSD() {
        File storages = getExternalFilesDir(null);

        if (storages.exists() ){
            //dirFicheiroSD = storages;
            String dir=storages.toString();
            if (Build.VERSION.SDK_INT >= 23) {
                File[] store = ContextCompat.getExternalFilesDirs(this, null);
                if (store.length > 1 && store[0] != null && store[1] != null){
                    //non deixa gardar na raiz da sd externa,solo na raiz da emulada en files dentro da externa
                   // dir=store[1].toString();
                    sdDisponhible=true;
                }
            }else
                sdDisponhible = true;
            dir = dir.replace("/Android/data/com.example.ud_a1a_a15manuelmd/files","");
            //Toast.makeText(this, dir, Toast.LENGTH_LONG).show();
            dirFicheiroSD = new File(dir);
            if (dirFicheiroSD.canWrite());
            sdAccesoEscritura=true;
            //rutaCompleta = new File(dirFicheiroSD.getAbsolutePath(), nomeFicheiro);
        }
        String estado = Environment.getExternalStorageState();
        Log.e("SD", estado);
    }
}
