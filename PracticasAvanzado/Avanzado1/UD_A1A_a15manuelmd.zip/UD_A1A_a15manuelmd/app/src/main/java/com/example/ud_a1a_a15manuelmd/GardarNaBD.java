package com.example.ud_a1a_a15manuelmd;

import androidx.appcompat.app.AppCompatActivity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class GardarNaBD extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gardar_na_bd);
    }
    public void onBotonGardarBD(View v){
            EditText edtNome=findViewById(R.id.edtNome);
            EditText edtDescrip=findViewById(R.id.edtDescripcion);
            if (edtDescrip.getText().toString().equals("") || edtNome.getText().toString().equals("")){
                Toast.makeText(this,"Non poden estar valeiros os campos nome e descripción",Toast.LENGTH_LONG).show();
               return;
            }
            BaseDeDatos db = new BaseDeDatos(getApplicationContext());
           SQLiteDatabase sqlLiteDB = db.getWritableDatabase();
            try {
                sqlLiteDB.execSQL("INSERT INTO PERSOAS(nome,Descricion) values('"+edtNome.getText().toString()+"','"+edtDescrip.getText().toString()+"')");
            }catch (Exception e){
                Toast.makeText(this,"Error na inserción, verifique que o nome non esta repetido",Toast.LENGTH_LONG).show();
            }
            edtDescrip.setText("");
            edtNome.setText("");
        }
    }
