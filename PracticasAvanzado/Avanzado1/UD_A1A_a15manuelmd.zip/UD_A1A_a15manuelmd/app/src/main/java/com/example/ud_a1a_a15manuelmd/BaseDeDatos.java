package com.example.ud_a1a_a15manuelmd;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BaseDeDatos extends SQLiteOpenHelper {
    SQLiteDatabase db;
    public final static String NOME_BD="DATOS";
    public final static int VERSION_BD=1;
    String CREAR_TABOA ="CREATE TABLE PERSOAS ( " +
            "nome  VARCHAR(30) PRIMARY KEY ," +
            "Descricion VARCHAR( 200 )  NOT NULL)";
    public BaseDeDatos(Context context) {
        super(context, NOME_BD, null, VERSION_BD);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        if(MainActivity.bdPorCodigo)
        db.execSQL(CREAR_TABOA);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}


}